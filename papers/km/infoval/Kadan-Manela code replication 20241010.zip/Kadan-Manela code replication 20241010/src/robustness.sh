#!/bin/bash
# A single script that queues all the jobs on RIS compute from a login node
# (except preprocessing the text into dtms and joining with macro data)
# To run this script use:
#   cp ~/.julia/dev/InfoVal/src/robustness.sh $STORAGE1/ManelaLab/InfoVal/code/
#   compute.connect
#   cd $STORAGE1/ManelaLab/InfoVal/code/
#   ./robustness.sh

# julia project path
# THISDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
PROJ=/usr/local/julia/depot/dev/InfoVal

# docker params to allocate shared memory for SharedArrays
# export LSF_DOCKER_NETWORK=host
# export LSF_DOCKER_IPC=host
# export LSF_DOCKER_SHM_SIZE=16g

BSUBCMD=(bsub \
 -q general \
 -n 4 \
 -J infoval \
 -M 384G \
 -W 1440 \
 -N -u amanela@wustl.edu \
 -R 'select[tmp>8G && mem>384G]' \
 -R 'rusage[tmp=8G,mem=384G]' \
 -R 'span[hosts=1]' \
 -a 'docker(registry.gitlab.com/manelalab/infoval.jl)' $PROJ/src/compute.sh)
 
BSUBARG=(run 'robustness')
echo running: "${BSUBCMD[@]} ${BSUBARG[@]}"
"${BSUBCMD[@]} ${BSUBARG[@]}"

# All of these arguments are optional, but they indicate some of the available features. In English, this means the job…
# is submitted to the foo-condo queue (-q foo-condo)
# is limited to running on the host group foo-condo (-m foo-condo)
# uses the job group my_group (-g my_group)
# has name my_name (-J my_name)
# requires 2 processors (-n 2)
# will be killed if its memory usage exceeds 8GB (-M 8000000 in KB)
# will be killed if it runs for longer than 10 minutes (-W 10)
# sends an email when it’s done, even with other output options specified (-N)
# any email sent goes to myemail@wustl.edu (-u)
# reads input_file into STDIN (-i input_file)
# overwrites output to ${HOME}/group/path/output_file (-oo)
# will only run on a host with more than 8000 MB of RAM and 2 GB of local temp disk (-R ‘select[mem>8000 && tmp>2]’)
# will consume 8000 MB of RAM, 2 GB of local temp disk (-R ‘rusage[mem=8000, tmp=2]’)
# will span only a single host (-R ‘span[hosts=1]’)
# will execute /usr/bin/some_program with no arguments

echo "done with robustness.sh"
