using Missings: missings, nonmissingtype

"Returns a lag `j` version of the `x` vector"
function lag(x::AbstractVector{F}, j::Int=1) where F
    T = length(x)
    lcol = missings(nonmissingtype(F), T)
    lcol[1+j:T] = x[1:T-j]
    lcol
end

"Returns a lead `j` version of the `x` vector"
function lead(x::AbstractVector{F}, j::Int) where F
    T = length(x)
    lcol = missings(nonmissingtype(F), T)
    lcol[1:T-j] = x[1+j:T]
    lcol
end

lagvar(v::Symbol, j::Int = 1) = Symbol(:lag, j, v)
leadvar(v::Symbol, j::Int = 1) = Symbol(:lead, j, v)

"Lag `j` of `df`'s column `col`"
function lag(df, col, j) 
    lag(df[!, col], j)
end

"""
Panel data lag takes a crosssection identifier `bycol` and timeseries identifier `tscol`.
The data must be sorted by `bycol` and then by `tscol`.
Sets to missing entires where the lag would have been from another `bycol`.
"""
function lag(df, lagcol, j, bycol, tscol)
    @assert issorted(df, [bycol, tscol]) "data must be sorted. Run sort!(df, $bycol, $tscol) first."

    T = size(df, 1)
    lcol = lag(df, lagcol, j)
    lbycol = lag(df, bycol, j)
    ixmiss = broadcast((lx,x)->ismissing(lx) || lx != x, lbycol, df[!, bycol])
    lcol[ixmiss] .= missing
    lcol
end

"Adds lag `j` of column `col` to `df`"
function lag!(df, col, j, args...)
    lcol = lagvar(col, j)
    df[!, lcol] = lag(df, col, j, args...)
    df
end

"Adds all the lags `j ∈ js` of column `col` to `df`"
function lag!(df, col, js::AbstractVector, args...)
    for j in js
        lag!(df, col, j, args...)
    end
    df
end

"Lead `j` of `df`'s column `col`"
function lead(df, col, j)
    lead(df[!, col], j)
end

"""
Panel data lead takes a crosssection identifier `bycol` and timeseries identifier `tscol`.
The data must be sorted by `bycol` and then by `tscol`.
Sets to missing entires where the lag would have been from another `bycol`.
"""
function lead(df, lagcol, j, bycol, tscol)
    @assert issorted(df, [bycol, tscol]) "data must be sorted. Run sort!(df, $bycol, $tscol) first."

    T = size(df, 1)
    lcol = lead(df, lagcol, j)
    lbycol = lead(df, bycol, j)
    ixmiss = broadcast((lx,x)->ismissing(lx) || lx != x, lbycol, df[!, bycol])
    lcol[ixmiss] .= missing
    lcol
end

"Adds lead `j` of column `col` to `df`"
function lead!(df, col, j, args...)
    T = size(df, 1)
    lcol = leadvar(col, j)
    df[!, lcol] = lead(df, col, j, args...)
    df
end

"Adds all the leads `j ∈ js` of column `col` to `df`"
function lead!(df, col, js::AbstractVector, args...)
    for j in js
        lead!(df, col, j, args...)
    end
end

"""
sumlag(x_t,h) = (x_t-h + x_t-h+1 + ... + x_t-1) / h
              = Σ_{j=1:h} x_{t-h+j-1} / h
              
NOTE: does not include contemporaneous variable
"""
function sumlag(df, col, h, args...)
    T = size(df, 1)
    dataType = eltype(df[!, col])
    lcol = missings(dataType, T)
    fill!(lcol, zero(dataType))

    for j = 1:h
        lcol += lag(df, col, j, args...)
    end

    lcol / h
end

"Adds sumlag `h` of column `col` to `df`"
function sumlag!(df, col, h, args...)
    lcol = Symbol("sumlag$h$col")
    df[!, lcol] = sumlag(df, col, h, args...)
    df
end

"""
sumlead(x_t,h) = (x_t + x_t+1 + ... + x_t+h-1) / h
               = Σ_{j=1:h} x_{t+j-1} / h
NOTE: includes contemporaneous variable so that sumlead(x,1) = x
"""
function sumlead(df, col, h, args...)
    T = size(df, 1)
    dataType = eltype(df[!, col])
    lcol = missings(dataType, T)
    fill!(lcol, zero(dataType))

    for j = 1:h
        lcol += lead(df, col, j-1, args...)
    end

    lcol / h
end

"Adds sumlead `h` of column `col` to `df`"
function sumlead!(df, col, h, args...)
    lcol = Symbol("sumlead$h$col")
    df[!, lcol] = sumlead(df, col, h, args...)
    df
end

"Adds all the sumlags `h ∈ hs` of column `col` to `df`"
function sumlag!(df, col, hs::AbstractVector, args...)
    for h in hs
        sumlag!(df, col, h, args...)
    end
end

"Adds all the sumleads `h ∈ hs` of column `col` to `df`"
function sumlead!(df, col, hs::AbstractVector, args...)
    for h in hs
        sumlead!(df, col, h, args...)
    end
end
