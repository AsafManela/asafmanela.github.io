using InfoVal: loaddata, analyze, robustness, Params, loadclean, logdir, jobid

using Logging, IOLogging

if !isinteractive()
    outfile = joinpath(logdir(),"run.$(jobid()).out.log")
    logger = FileLogger(Dict(Logging.Info => outfile))
    global_logger(logger)
end

@info "runall started"

analyze(; cachedata=true)

# just baseline
# analyze(; approaches=[:flam], dirs=[:CLNV])

# make up analysis
# params = Params(minprice=0, cachedata=true)
# infovaldf = loadclean(params)
# analyze(infovaldf, params)

# collect into robustness tables and figures
robustness()

@info "runall done"
