#!/bin/bash

TAQHOME=/home/wustl/amanela/taq

grep -P '^((?=.*ERROR:)(?!.*valid)(?!.*Errors printed))' $TAQHOME/sas_logs/dailytaq.*.log

