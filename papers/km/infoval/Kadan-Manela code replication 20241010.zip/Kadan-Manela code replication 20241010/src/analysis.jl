"Recession dates"
function recdf(df) 
    rec = DataFrame(from=[Date(2007,12,1), Date(2020,2,1)], to=[Date(2009,6,30), Date(2020,4,30)])
    mindate = minimum(df.date)
    maxdate = maximum(df.date)
    for c = [:from, :to]
        clamp!(rec[!, c], mindate, maxdate)
    end
    rec
end

"Shades layer for recessions"
recshades(df) = recdf(df) |> @vlplot(mark={:rect, opacity=0.2, color=:gray}, x=:from, x2=:to, )

"Aggregate data to monthly observations"
function agg(df, f::Function=lastdayofmonth; 
        mindate=Date(2000,1,1), 
        maxdate=Date(2050,1,1),
        byvar=:date
    )

    ix = [!ismissing(d) && d >= mindate && d <= maxdate for d in df.date] .& [!ismissing(d) for d in df[!, byvar]]

    df = df[ix, [byvar, :Vw, :λpw, :rvw, :permno]]

    df.aggbyvar = f.(df[!, byvar])

    aggdf = combine(groupby(df, :aggbyvar; sort=true),
        # first-order approximation for the mean:
        [:rvw, :λpw] => meanratio => :Vw, 
        # byvar-clustered CIs
        [:rvw, :λpw, byvar] => bt95ratio => :VwBt95,
        [:rvw, :λpw, byvar] => up95ratio => :VwUp95,
        :λpw => mean => :λpw,
        :λpw => bt95 => :λpwBt95,
        :λpw => up95 => :λpwUp95,
        :rvw => mean => :rvw,
        :rvw => bt95 => :rvwBt95,
        :rvw => up95 => :rvwUp95,
        :Vw => length => :nobs,
        :permno => length ∘ unique => :nstocks
    )

    rename!(aggdf, :aggbyvar=>byvar)
end

#########################################################
# Estimating ratios
#   References:
#   - stata ratio manual: https://www.stata.com/manuals13/rratio.pdf
#   - 
#########################################################

"Mean of ratio `z=y/x`, first-order Taylor approximation"
meanratio(y, x) = sum(y) / sum(x)

function Σratio(y, x, clusvar)
    X = [y x]
    Σ = lrvar(CRHC1(clusvar), X)
    (σy2=Σ[1,1], σx2=Σ[2,2], σxy=Σ[1,2])
end

"Variance of ratio `z=y/x`"
function varratio(y, x, args...) 
    μx = mean(x)
    μy = mean(y)
    R = μy / μx

    Σ = Σratio(y, x, args...)

    (Σ.σx2*R^2 + Σ.σy2 - 2*Σ.σxy*R) / μx^2
end

# 95% CIs
semeanratio(y, x, args...) = sqrt(varratio(y, x, args...) / length(y))
up95ratio(y, x, args...) = meanratio(y, x) + 1.96*semeanratio(y, x, args...)
bt95ratio(y, x, args...) = meanratio(y, x) - 1.96*semeanratio(y, x, args...)

"""
    Snw(g0,m=0)

Author: Söderlind, Paul

Calculates covariance matrix of sqrt(T)*sample average.

# Usage
S = NWFn(g0,m)

# Input
- `g0::Array`: Txq array of q moment conditions
- `m:int`: scalar, number of lags to use

# Output
- `S::Array`: qxq covariance matrix

"""
function Snw(g0,m=0)

    T = size(g0,1)                    #g0 is Txq
    m = min(m,T-1)                    #number of lags

    g = g0 .- mean(g0,dims=1)  #Normalizing to Eg=0, 0.7 syntax

    S = g'g/T                         #(qxT)*(Txq)
    for s = 1:m
    Gamma_s = g[s+1:T,:]'g[1:T-s,:]/T   #same as Sum[g(t)*g(t-s)',t=s+1,T]
    S       = S  +  ( 1 - s/(m+1) ) * (Gamma_s + Gamma_s')
    end

    return S

end

"Aggregate data to monthly size-b/m observations"
function aggxsxbm(df, f::Function=lastdayofmonth)
    df.aggdate = f.(df.date)

    portdf = dropmissing!(copy(df), [:Vw, :aggdate, :szport, :bmport])

    aggdf = combine(groupby(portdf, [:aggdate, :szport, :bmport]; sort=true), 
        :Vw => mean => :Vw,
        :Vw => up95 => :VwUp95,
        :Vw => bt95 => :VwBt95,
        :Vw => length => :nobs,
        :permno => length ∘ unique => :nstocks
    )
    
    aggdf.sz = categorical([s == "B" ? "Big" : "Small" for s in aggdf.szport])
    aggdf.bm = categorical([s == "H" ? "Value" : (s == "M" ? "Medium" : "Growth") for s in aggdf.bmport])
    aggdf.Portfolio = categorical(aggdf.sz .* "-" .* aggdf.bm)

    rename!(aggdf, :aggdate=>:date)

    sort!(aggdf, [:Portfolio, :date])

    aggdf
end

    
"Aggregate data to monthly size observations"
function aggxsize(df, f::Function=lastdayofmonth)
    df.aggdate = f.(df.date)

    portdf = dropmissing!(copy(df), [:Vw, :aggdate, :szport])

    aggdf = combine(groupby(portdf, [:aggdate, :szport]), 
        :Vw => mean => :Vw,
        :Vw => up95 => :VwUp95,
        :Vw => bt95 => :VwBt95,
        :Vw => length => :nobs,
        :permno => length ∘ unique => :nstocks
    )
    
    aggdf.Portfolio = categorical([s == "B" ? "Big" : "Small" for s in aggdf.szport])

    rename!(aggdf, :aggdate=>:date)

    sort!(aggdf, [:Portfolio, :date])

    aggdf
end

"Aggregate data to monthly observations using a FE regression to get CI"
function aggreg(df, f::Function=lastdayofmonth; byvar=:date,
        mindate=Date(2000,1,1), maxdate=Date(2050,1,1),
        ys = [:Vw, :λpw, :rvw],
        vcov = [Vcov.cluster(byvar, :permno), Vcov.simple(), Vcov.simple()]
    )

    @assert isa(vcov, CovarianceEstimator) || length(vcov) == length(ys) "`vcov` should be a single CovarianceEstimator or a vector of them of same length as `ys`"

    if isa(vcov, CovarianceEstimator)
        vcovs = repeat([vcov], length(ys))
    else
        vcovs = vcov
    end

    ix = [!ismissing(d) && d >= mindate && d <= maxdate for d in df.date] .& [!ismissing(d) for d in df[!, byvar]]

    if iszero(sum(ix))
        @warn "No observations left in df after filtering"
        return DataFrame()
    end

    df = df[ix, vcat([byvar, :permno], ys)]

    df.aggbyvar = categorical(f.(df[!, byvar]); ordered=true)

    aggdf = DataFrame(byvar=>levels(df.aggbyvar))

    for i = 1:length(ys)
        y = ys[i]
        v = vcovs[i]
        f = term(y) ~ term(0) + term(:aggbyvar)
        @info "regressing $f with $v"
        m = reg(df, f, v)
        @show m
        β = coef(m)
        ci = confint(m)
        aggdf[!, y] = β
        aggdf[!, Symbol(y, "Bt95")] = ci[:,1]
        aggdf[!, Symbol(y, "Up95")] = ci[:,2]
    end

    aggdf
end

"Aggregate data to monthly observations by size using a FE regression to get CI"
function aggregxsize(df, f::Function=lastdayofmonth; 
        mindate=Date(2000,1,1), maxdate=Date(2050,1,1),
        ys = [:Vw, :λpw, :rvw],
        vcov = [Vcov.robust(), Vcov.simple(), Vcov.simple()]
    )

    @assert isa(vcov, CovarianceEstimator) || length(vcov) == length(ys) "`vcov` should be a single CovarianceEstimator or a vector of them of same length as `ys`"

    if isa(vcov, CovarianceEstimator)
        vcovs = repeat([vcov], length(ys))
    else
        vcovs = vcov
    end

    ix = [!ismissing(d) && d >= mindate && d <= maxdate for d in df.date]

    df = df[ix, vcat([:date, :permno, :szport], ys)]

    df.aggdate = categorical(f.(df.date); ordered=true)

    uniquedates = levels(df.aggdate)
    uniqueport = levels(df.szport)
    @assert uniqueport == ["B", "S"]

    aggdf = DataFrame(date=repeat(uniquedates, outer=length(uniqueport)))
    aggdf.Portfolio = repeat(["Big", "Small"], inner=length(uniquedates))

    for i = 1:length(ys)
        y = ys[i]
        v = vcovs[i]
        f = term(y) ~ term(0) + term(:aggdate) & term(:szport)
        @info "regressing $f with $v"
        m = reg(df, f, v)
        @show m
        β = coef(m)
        ci = confint(m)
        aggdf[!, y] = β
        aggdf[!, Symbol(y, "Bt95")] = ci[:,1]
        aggdf[!, Symbol(y, "Up95")] = ci[:,2]
    end

    aggdf
end


"Aggregate data to monthly observations by size x bm using a FE regression to get CI"
function aggregxsxbm(df, f::Function=lastdayofmonth; byvar=:date,
        mindate=Date(2000,1,1), maxdate=Date(2050,1,1),
        ys = [:Vw, :λpw, :rvw],
        vcov = [Vcov.robust(), Vcov.simple(), Vcov.simple()]
    )

    @assert isa(vcov, CovarianceEstimator) || length(vcov) == length(ys) "`vcov` should be a single CovarianceEstimator or a vector of them of same length as `ys`"

    if isa(vcov, CovarianceEstimator)
        vcovs = repeat([vcov], length(ys))
    else
        vcovs = vcov
    end

    ix = [!ismissing(d) && d >= mindate && d <= maxdate for d in df[!, byvar]]

    if iszero(sum(ix))
        @warn "No observations left in df after filtering"
        return DataFrame()
    end

    df = df[ix, vcat([byvar, :permno, :szport, :bmport], ys)]

    df.aggbyvar = categorical(f.(df[!, byvar]); ordered=true)
    sz = categorical([s == "B" ? "Big" : "Small" for s in df.szport])
    bm = categorical([s == "H" ? "Value" : (s == "M" ? "Medium" : "Growth") for s in df.bmport])
    df.Portfolio = categorical(sz .* "-" .* bm)

    uniquedates = levels(df.aggbyvar)
    uniqueport = levels(df.Portfolio)
    @assert uniqueport == ["Big-Growth"
                            "Big-Medium"
                            "Big-Value"
                            "Small-Growth"
                            "Small-Medium"
                            "Small-Value"]

    aggdf = DataFrame(byvar=>repeat(uniquedates, outer=length(uniqueport)))
    aggdf.Portfolio = repeat(uniqueport, inner=length(uniquedates))

    for i = 1:length(ys)
        y = ys[i]
        v = vcovs[i]
        f = term(y) ~ term(0) + term(:aggbyvar) & term(:Portfolio)
        @info "regressing $f with $v"
        m = reg(df, f, v)
        @show m
        β = coef(m)
        ci = confint(m)
        aggdf[!, y] = β
        aggdf[!, Symbol(y, "Bt95")] = ci[:,1]
        aggdf[!, Symbol(y, "Up95")] = ci[:,2]
    end

    aggdf
end
 
function plotinfoval(aggdf::DataFrame; 
        xtitle = "Month",
        shades = false
    )
    p = aggdf |>
    @vlplot(x = {field=:date, title="Month"}, 
        config = {
            font = "Utopia",
        }
    ) +
    @vlplot(
        :errorband,
        encoding = {
            y = {
                "VwUp95:q",
                title = "Value of information, USD millons per year (95% CIs)"
            },
            y2 = {
                "VwBt95:q"
            },
        },
        width = 800,
        height = 450
    ) +
    @vlplot(
        :line,
        y = :Vw
    )

    p = @set p.encoding.x.title = xtitle
    
    if shades
        p = p + recshades(aggdf)
    end

    p
end

function plotinfovalwithλandrv(aggdf::DataFrame; 
        xfield="date",
        xtype="temporal",
        xtitle="date",
        dV=(x=-140, y=-40),
        drv=(x=0, y=-20),
        dλ=(x=0, y=20),
        shades=false
    )

    p = aggdf |> vl"""
    {
        "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
        "description": "A simple bar chart with embedded data.",
        "config": {
            "font": "Utopia",
            "axisLeft": {"domainColor": "#4c78a8", "tickColor": "#4c78a8", "labelColor": "#4c78a8"},
            "axisRight": {"domainColor": "#ff7f0e", "tickColor": "#ff7f0e", "labelColor": "#ff7f0e"},
            "mark": {"fontStyle": "bold"}
        },
        "width": "800",
        "height": "450",
        "transform": [
            {"calculate": "log(datum.λpw)", "as": "lnλpw"},
            {"calculate": "log(datum.rvw)", "as": "lnrvw"}
        ],
        "encoding": {
            "x": {
                "field": "date",
                "type": "temporal"
            }
        },
        "layer": [
            {
                "layer": [
                            {
                        "mark": {
                            "type": "line",
                            "strokeDash": [6, 4],
                            "color": "#ff7f0e"
                        },
                        "encoding": {
                            "y": {
                                "field": "lnrvw",
                                "axis": {
                                    "title": null,
                                    "orient": "right"
                                },
                                "type": "quantitative"
                            }
                        }
                    },
                    {
                        "mark": {
                            "type": "line",
                            "strokeDash": [2, 2],
                            "color": "#ff7f0e"
                        },
                        "encoding": {
                            "y": {
                                "field": "lnλpw",
                                "axis": {
                                    "title": null,
                                    "orient": "right"
                                },
                                "type": "quantitative"
                            }
                        }
                    },
                    {
                        "encoding": {
                            "x": {"aggregate": "mean", "field": "date", "type": "temporal"},
                            "y": {
                                "aggregate": "mean",
                                "field": "lnrvw",
                                "type": "quantitative",
                                "axis": {
                                    "orient": "right"
                                }
                            }
                        },
                        "layer": [
                            {
                                "mark": {
                                    "type": "text", 
                                    "align": "left", 
                                    "dy": -20, 
                                    "text": "log Return Variance (right scale)",
                                    "color": "#ff7f0e"
                                }
                            }
                        ]
                    },
                    {
                        "encoding": {
                            "x": {"aggregate": "mean", "field": "date", "type": "temporal", "title": "date"},
                            "y": {
                                "aggregate": "mean",
                                "field": "lnλpw",
                                "type": "quantitative",
                                "axis": {
                                    "orient": "right"
                                }
                            }
                        },
                        "layer": [
                            {
                                "mark": {
                                    "type": "text", 
                                    "align": "left", 
                                    "dy": 20, 
                                    "text": "log Price Impact (right scale)",
                                    "color": "#ff7f0e"
                                }
                            }
                        ]
                    }
                ]
            },
            {
                "layer": [
                    {
                        "mark": "errorband",
                        "encoding": {
                            "y": {
                                "field": "VwUp95",
                                "axis": {
                                    "title": null,
                                    "orient": "left"
                                },
                                "type": "quantitative"
                            },
                            "y2": {
                                "field": "VwBt95",
                                "type": "quantitative"
                            }
                        }
                    },
                    {
                        "mark": "line",
                        "encoding": {
                            "y": {
                                "field": "Vw",
                                "type": "quantitative",
                                "axis": {
                                    "orient": "left"
                                }
                            }
                        }
                    },
                    {
                        "encoding": {
                            "x": {"aggregate": "mean", "field": "date", "type": "temporal"},
                            "y": {
                                "aggregate": "mean",
                                "field": "Vw",
                                "type": "quantitative",
                                "axis": {
                                    "orient": "left"
                                }
                            }
                        },
                        "layer": [
                            {
                                "mark": {
                                    "type": "text", 
                                    "align": "left", 
                                    "dy": -40, 
                                    "dx": -140, 
                                    "text": "Value of information, USD millons per year (left scale)",
                                    "color": "#4c78a8"
                                }
                            }
                        ]
                    }
                ]
            }
        ],
        "resolve": { "scale": { "y": "independent"}}
    }
    """

    p = @set p.encoding.x.field = xfield
    p = @set p.encoding.x.type = xtype
    p = @set p.encoding.x.title = xtitle

    for (l1,l2) = ((1,3), (1,4), (2,3))
        xelem = p.layer[l1]["layer"][l2]["encoding"]["x"]
        xelem["field"] = xfield
        xelem["type"] = xtype
        xelem["title"] = xtitle
    end

    rvmark = p.layer[1]["layer"][3]["layer"][1]["mark"]
    rvmark["dx"] = drv.x
    rvmark["dy"] = drv.y

    Vmark = p.layer[2]["layer"][3]["layer"][1]["mark"]
    Vmark["dx"] = dV.x
    Vmark["dy"] = dV.y

    λmark = p.layer[1]["layer"][4]["layer"][1]["mark"]
    λmark["dx"] = dλ.x
    λmark["dy"] = dλ.y

    if shades
        p = p + recshades(aggdf)
    end

    p
end

function plotlninfovalwithλandrv(aggdf::DataFrame; 
        xfield="date",
        xtype="temporal",
        xtitle="date",
        dV=(x=-140, y=-40),
        drv=(x=0, y=-20),
        dλ=(x=0, y=20),
        shades=false
    )

    p = aggdf |> vl"""
    {
        "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
        "description": "A simple bar chart with embedded data.",
        "config": {
            "font": "Utopia",
            "axisLeft": {"domainColor": "#4c78a8", "tickColor": "#4c78a8", "labelColor": "#4c78a8"},
            "axisRight": {"domainColor": "#ff7f0e", "tickColor": "#ff7f0e", "labelColor": "#ff7f0e"},
            "mark": {"fontStyle": "bold"}
        },
        "width": "800",
        "height": "450",
        "encoding": {
            "x": {
                "field": "date",
                "type": "temporal"
            }
        },
        "layer": [
            {
                "layer": [
                            {
                        "mark": {
                            "type": "line",
                            "strokeDash": [6, 4],
                            "color": "#ff7f0e"
                        },
                        "encoding": {
                            "y": {
                                "field": "lnrvw",
                                "axis": {
                                    "title": null,
                                    "orient": "right"
                                },
                                "type": "quantitative"
                            }
                        }
                    },
                    {
                        "mark": {
                            "type": "line",
                            "strokeDash": [2, 2],
                            "color": "#ff7f0e"
                        },
                        "encoding": {
                            "y": {
                                "field": "lnλpw",
                                "axis": {
                                    "title": null,
                                    "orient": "right"
                                },
                                "type": "quantitative"
                            }
                        }
                    },
                    {
                        "encoding": {
                            "x": {"aggregate": "mean", "field": "date", "type": "temporal"},
                            "y": {
                                "aggregate": "mean",
                                "field": "lnrvw",
                                "type": "quantitative",
                                "axis": {
                                    "orient": "right"
                                }
                            }
                        },
                        "layer": [
                            {
                                "mark": {
                                    "type": "text", 
                                    "align": "left", 
                                    "dy": -20, 
                                    "text": "log Return Variance (right scale)",
                                    "color": "#ff7f0e"
                                }
                            }
                        ]
                    },
                    {
                        "encoding": {
                            "x": {"aggregate": "mean", "field": "date", "type": "temporal", "title": "date"},
                            "y": {
                                "aggregate": "mean",
                                "field": "lnλpw",
                                "type": "quantitative",
                                "axis": {
                                    "orient": "right"
                                }
                            }
                        },
                        "layer": [
                            {
                                "mark": {
                                    "type": "text", 
                                    "align": "left", 
                                    "dy": 20, 
                                    "text": "log Price Impact (right scale)",
                                    "color": "#ff7f0e"
                                }
                            }
                        ]
                    }
                ]
            },
            {
                "layer": [
                    {
                        "mark": "errorband",
                        "encoding": {
                            "y": {
                                "field": "lnVwUp95",
                                "axis": {
                                    "title": null,
                                    "orient": "left"
                                },
                                "type": "quantitative"
                            },
                            "y2": {
                                "field": "lnVwBt95",
                                "type": "quantitative"
                            }
                        }
                    },
                    {
                        "mark": "line",
                        "encoding": {
                            "y": {
                                "field": "lnVw",
                                "type": "quantitative",
                                "axis": {
                                    "orient": "left"
                                }
                            }
                        }
                    }
                    ,
                    {
                        "encoding": {
                            "x": {"aggregate": "mean", "field": "date", "type": "temporal"},
                            "y": {
                                "aggregate": "mean",
                                "field": "lnVw",
                                "type": "quantitative",
                                "axis": {
                                    "orient": "left"
                                }
                            }
                        },
                        "layer": [
                            {
                                "mark": {
                                    "type": "text", 
                                    "align": "left", 
                                    "dy": -40, 
                                    "dx": -140, 
                                    "text": "log Value of information (left scale)",
                                    "color": "#4c78a8"
                                }
                            }
                        ]
                    }
                ]
            }
        ],
        "resolve": { "scale": { "y": "independent"}}
    }
    """

    p = @set p.encoding.x.field = xfield
    p = @set p.encoding.x.type = xtype
    p = @set p.encoding.x.title = xtitle

    for (l1,l2) = ((1,3), (1,4), (2,3))
        xelem = p.layer[l1]["layer"][l2]["encoding"]["x"]
        xelem["field"] = xfield
        xelem["type"] = xtype
        xelem["title"] = xtitle
    end

    rvmark = p.layer[1]["layer"][3]["layer"][1]["mark"]
    rvmark["dx"] = drv.x
    rvmark["dy"] = drv.y

    Vmark = p.layer[2]["layer"][3]["layer"][1]["mark"]
    Vmark["dx"] = dV.x
    Vmark["dy"] = dV.y

    λmark = p.layer[1]["layer"][4]["layer"][1]["mark"]
    λmark["dx"] = dλ.x
    λmark["dy"] = dλ.y

    if shades
        p = p + recshades(aggdf)
    end

    p
end


function plotinfovalportfolios(aggdf::DataFrame; 
        xtitle="Month",
        shades=false
    )

    p = aggdf |>
    @vlplot(x = {field=:date, title="Month"}, 
        config = {
            font = "Utopia",  
            background = "white",
        }
    ) +
    @vlplot(
        :errorband,
        encoding = {
            y = {
                "VwUp95:q",
                title = "Value of information, USD millons per year (95% CIs)"
            },
            y2 = {
                "VwBt95:q"
            },
            color = :Portfolio,
        },
        width = 800,
        height = 450
    ) +
    @vlplot(
        :line,
        y = :Vw,
        color = :Portfolio
    )

    p = @set p.encoding.x.title = xtitle

    if shades
        p = p + recshades(aggdf)
    end

    p
end

function plotlninfovalportfolios(aggdf::DataFrame; 
        xtitle="Month",
        shades=false
    )

    p = aggdf |>
    @vlplot(x = {field=:date, title="Month"}, 
        config = {
            font = "Utopia",  
            background = "white",
        }
    ) +
    @vlplot(
        :errorband,
        encoding = {
            y = {
                "lnVwUp95:q",
                title = "log Value of information, USD millons per year (95% CIs)"
            },
            y2 = {
                "lnVwBt95:q"
            },
            color = :Portfolio,
        },
        width = 800,
        height = 450
    ) +
    @vlplot(
        :line,
        y = :lnVw,
        color = :Portfolio
    )

    p = @set p.encoding.x.title = xtitle

    if shades
        p = p + recshades(aggdf)
    end

    p
end

function drawinfoval(aggdf::DataFrame, params::Params, by::String, args...; portfolios = false, 
        terms=false, byvar=:date, kwargs...)

    if isempty(aggdf)
        @warn "Empty aggdf. Skipping ..."
    else
        if portfolios
            p = plotinfovalportfolios(aggdf, args...; kwargs...)
        else
            if terms
                p = plotinfovalwithλandrv(aggdf, args...; kwargs...)
                by*="terms"
            else
                p = plotinfoval(aggdf, args...; kwargs...)
            end
        end
        
        minbyvar = minimum(aggdf[!,byvar])
        maxbyvar = maximum(aggdf[!,byvar])
        if isa(minbyvar, Date)
            from = year(minbyvar) * 100 + month(minbyvar)
            to = year(maxbyvar) * 100 + month(maxbyvar)
        else
            from = minbyvar
            to = maxbyvar
        end

        figfile = joinpath(figdir(), "infoval_$(by)$(params)_$(from)_$(to).pdf")
        p |> save(figfile)
        @info "drew infoval to $figfile"
        p
    end
end 

function drawlninfoval(aggdf::DataFrame, params::Params, by::String, args...; portfolios = false, 
        terms=false, byvar=:date, kwargs...)

    if isempty(aggdf)
        @warn "Empty aggdf. Skipping ..."
    else
        if portfolios
            p = plotlninfovalportfolios(aggdf, args...; kwargs...)
        else
            if terms
                p = plotlninfovalwithλandrv(aggdf, args...; kwargs...)
                by*="terms"
            else
                p = plotlninfoval(aggdf, args...; kwargs...)
            end
        end
        
        minbyvar = minimum(aggdf[!,byvar])
        maxbyvar = maximum(aggdf[!,byvar])
        if isa(minbyvar, Date)
            from = year(minbyvar) * 100 + month(minbyvar)
            to = year(maxbyvar) * 100 + month(maxbyvar)
        else
            from = minbyvar
            to = maxbyvar
        end

        figfile = joinpath(figdir(), "lninfoval_$(by)$(params)_$(from)_$(to).pdf")
        p |> save(figfile)
        @info "drew infoval to $figfile"
        p
    end
end 

function completelogs(df, cols=[:Vw, :Viw, :rvw, :λpw])
    # create log lhs vars
    for c in cols
        df[!, Symbol(:ln, c)] = logmiss.(df[!, c])
    end

    # only include cases where all lhs vars are not missing
    newcols = [Symbol(:ln, c) for c in cols]
    dropmissing(df, newcols)
end

const labels = Dict(
        "Vw" => "Information value",
        "Viw" => "Information value (intraday)",
        "rvw" => "Return variance",
        "λpw" => "Price impact per \\\$M",
        "lnVw" => "log Information value",
        "lnViw" => "log Information value (intraday)",
        "lnrvw" => "log Return variance",
        "lnλpw" => "log Price impact",
        "lnwtw" => "Size",
        "bemew" => "Book-to-market",
        "date" => "Date (day) FE",
        "permno" => "Stock FE",
        "lnwtw & bemew" => "Size x Book-to-market",
        "ead" => "Earnings",
        "momretw" => "Momentum",
        "numest_excw" => "Analysts",
        "disp2w" => "Analyst Disp.",
        "(Intercept)" => "Intercept"
    )

# * 10%, ** 5%, *** 1%
latex_estim_decoration(s::String, pval::Missing) = s

function latex_estim_decoration(s::String, pval::Float64)
    if pval<0.0
        error("p value needs to be nonnegative.")
    end
    if (pval > 0.10)
        return "$s"
    elseif (pval > 0.05)
        return "$s\\sym{*}"
    elseif (pval > 0.01)
        return "$s\\sym{**}"
    else
        return "$s\\sym{***}"
    end
end


mylatexTableHeader(numberOfResults::Int64, align::String) = "\\begin{tabular*}{1\\columnwidth}{@{\\hskip\\tabcolsep\\extracolsep\\fill}l*{$(numberOfResults-1)}{r}}"
mylatexTableFooter(numberOfResults::Int64, align::String) = "\\end{tabular*}"
function mylatexOutput(outfile::String = "")
    # baseline
    rs = latexOutput(outfile)
    @extract rs : toprule midrule bottomrule headerrule headercolsep colsep linestart 
    @extract rs : linebreak label_fe_yes label_fe_no
    @extract rs : label_statistic_n label_statistic_r2 label_statistic_adjr2 label_statistic_r2_within
    @extract rs : label_statistic_f label_statistic_p label_statistic_f_kp label_statistic_p_kp label_statistic_dof
    @extract rs : label_estimator label_estimator_ols label_estimator_iv label_estimator_nl
    @extract rs : outfile encapsulateRegressand

    # my tweaks
    header = mylatexTableHeader
    footer = mylatexTableFooter
    
    RenderSettings(toprule, midrule, bottomrule, headerrule, headercolsep, colsep, linestart, 
        linebreak, label_fe_yes, label_fe_no,
        label_statistic_n, label_statistic_r2, label_statistic_adjr2, label_statistic_r2_within,
        label_statistic_f, label_statistic_p, label_statistic_f_kp, label_statistic_p_kp, label_statistic_dof,
        label_estimator, label_estimator_ols, label_estimator_iv, label_estimator_nl,
        outfile, encapsulateRegressand, header, footer)
end

period(infovaldf::DataFrame) = format(minimum(infovaldf.date), "Ymd") * "to" * format(maximum(infovaldf.date), "Ymd")

regname(f, v, infovaldf::DataFrame) = regname(f, v, period(infovaldf))

function regname(f, v, period::String)
    fstr = string(f)
    for r in [":(fe("=>"fe", " + "=>"_", "))"=>""," ~ "=>"_on_"]
        fstr = replace(fstr, r)
    end

    clusters = join(string.(v.clusternames), "_")
    
    "$fstr.cl_$clusters.$period"
end

# wrapper for regtable that omits the intercept
function regtablenointercept(rr...; 
    regressors::Vector{String} = Vector{String}(), kwargs...)

    # ordering of regressors:
    if length(regressors) == 0
        # construct default ordering: from ordering in regressions (like in Stata)
        regressorList = Vector{String}()
        for r in rr # FixedEffectModel
            names = coefnames(r)
            for regressorIndex = 1:length(names)
                coefname = names[regressorIndex]

                # omit intercept and already included regressors
                if (coefname != "(Intercept)") && !(any(regressorList .== coefname))
                    # add to list
                    push!(regressorList, coefname)
                end
            end
        end
    else
        # take the list of regressors from the argument
        regressorList = regressors
    end

    regtable(rr...; regressors = regressorList, kwargs...)
end

function regs(infovaldf::DataFrame, params::Params, rhs::Vector{Symbol}; 
        lhs::Vector{Symbol}=[:Vw, :Viw, :rvw, :λpw],
        method=:cpu, double_precision=(method==:cpu),
        v = Vcov.cluster(:date, :permno),
        kwargs...
        )
    startyyyymm = minimum(infovaldf.yyyymm)
    endyyyymm = maximum(infovaldf.yyyymm)
    resname = "reg$(params)_$(startyyyymm)_$(endyyyymm)"
    rhsstr = join(string.(rhs),"_")
    lhsstr = join(string.(lhs),"_")
    lhsstr12 = join(string.(lhs[1:2]),"_")
    lhsstr34 = join(string.(lhs[3:4]),"_")

    r = term.(rhs)
    fes0 = @formula(1 ~ 1 + fe(date) + fe(permno)).rhs
    fes = [fes0[1:1], fes0[2:2], fes0[3:3], fes0[2:3]]
    
    fs = Vector{Any}()
    regs = Vector{FixedEffectModel}()

    for l in lhs, fe in fes
        f = term(l) ~ sum((r..., fe...))
        push!(fs, f)
        @info "running $f"
    
        m = cache(reg, regname(f,v,infovaldf), params, infovaldf, f, v;
            method=method, double_precision=double_precision, kwargs...)

        push!(regs, m)
    end

    filepath = replace(joinpath(tbldir(), "$(resname)_$(lhsstr)_on_$rhsstr.tex"), "λ"=>"lam")
    filepath12 = replace(joinpath(tbldir(), "$(resname)_$(lhsstr12)_on_$rhsstr.tex"), "λ"=>"lam")
    filepath34 = replace(joinpath(tbldir(), "$(resname)_$(lhsstr34)_on_$rhsstr.tex"), "λ"=>"lam")

    regargs = (labels = labels, print_estimator_section = false, estim_decoration=latex_estim_decoration, estimformat="%0.2f", statisticformat="%0.2f")
    regtablenointercept(regs...; renderSettings = mylatexOutput(filepath), regargs...)
    regtablenointercept(regs[1:8]...; renderSettings = mylatexOutput(filepath12), regargs...)
    regtablenointercept(regs[9:16]...; renderSettings = mylatexOutput(filepath34), regargs...)
    
    @info "regs written to $filepath"
end 

"Returns the point estimate of `coefsym` from a (cached) regression of `lhs` on `rhs` with `params`"
function singleregcoef(lhs::Symbol, rhs::Vector{Symbol}, period::String, params, coefsym, specsubstr)
    kwargs = (approaches=[params.approach], dirs=[params.dir], test=params.test)
    resdf = robustregcoef(lhs, rhs, period; kwargs...)
    ixparams = broadcast(x->isequal(string(x), string(params)), resdf.params)
    ixcoef = broadcast(isequal(coefsym), resdf.coefsym)
    ixspec = broadcast(contains(specsubstr), resdf.specname)

    first(resdf.mu[ixparams .& ixcoef .& ixspec])
end

"Save notable results mentioned explicitly in the text to a tex file for inclusion"
function noteableresults(infovaldf::DataFrame, params::Params)
    EVwannualUSDm = meanratio(infovaldf.rvw, infovaldf.λpw)
    EVwdailyUSD = EVwannualUSDm / 252 * 10^6
    EVwdailyUSDapprox = div(EVwdailyUSD, 100) * 100
    StdVw = sqrt(varratio(infovaldf.rvw, infovaldf.λpw, infovaldf.date))

    nstocks = div(length(unique(infovaldf.permno)), 100) * 100

    medianvolintraday = median(infovaldf.σiw) * 100
    medianvol = median(infovaldf.σw) * 100
    medianvolovernight = (medianvol-medianvolintraday)/medianvolintraday * 100
    medianpriceimpact = median(infovaldf.λpw)
    medianpriceimpactpct = medianpriceimpact * 100
    medianmktcapUSDb = median(infovaldf.wt) / 10^6
    medianbemepct = median(infovaldf.bemew) * 100
    medianmompct = median(infovaldf.momretw) * 100
    
    negativeVwpct = sum(x->x<0, infovaldf.λp) / size(infovaldf,1) * 100

    # regression results
    period = "2003911to20201231"
    if params.test
        period = "2020425to2020514"
    end

    sizeeffectonvaluenofe = singleregcoef(:lnVw, [:lnwtw], period, params, :lnwtw, "No FE")
    sizereducesvar = -singleregcoef(:lnrvw, [:lnwtw], period, params, :lnwtw, "No FE")
    sizereduceslambda = -singleregcoef(:lnλpw, [:lnwtw], period, params, :lnwtw, "No FE")

    settexresults(params,
        "EVwannualUSDm"=>Formatting.format(EVwannualUSDm, precision=1),
        "StdVwannualUSDm"=>Formatting.format(StdVw, precision=0),
        "EVwdailyUSD"=>Formatting.format(EVwdailyUSD, precision=0, commas=true),
        "EVwdailyUSDapprox"=>Formatting.format(EVwdailyUSDapprox, precision=0, commas=true),
        "nstocks"=>Formatting.format(nstocks, commas=true),
        "medianmompct"=>Formatting.format(medianmompct, precision=0),
        "medianbemepct"=>Formatting.format(medianbemepct, precision=0),
        "medianmktcapUSDb"=>Formatting.format(medianmktcapUSDb, precision=0),
        "medianpriceimpact"=>Formatting.format(medianpriceimpact, precision=2),
        "medianpriceimpactpct"=>Formatting.format(medianpriceimpactpct, precision=0),
        "medianvolintraday"=>Formatting.format(medianvolintraday, precision=0),
        "medianvol"=>Formatting.format(medianvol, precision=0),
        "medianvolovernight"=>Formatting.format(medianvolovernight, precision=0),
        "negativeVwpct"=>Formatting.format(negativeVwpct, precision=0),
        "sizeeffectonvaluenofe"=>Formatting.format(sizeeffectonvaluenofe, precision=2),
        "sizereducesvar"=>Formatting.format(sizereducesvar, precision=2),
        "sizereduceslambda"=>Formatting.format(sizereduceslambda, precision=2),
    )
end

function analyze(; kwparams...)

    ps = allparams(; kwparams...)

    @info "analyzing $(length(ps)) parameter sets"

    for params in ps
        infovaldf = loadclean(params)

        analyze(infovaldf, params)
    end

    @info "Done analyzing."
end 

function analyze(levelinfovaldf::DataFrame, params::Params; levelkwargs...)
    @info "analyze with params=$params"

    @info "Summary stats ..."
    summarystats(levelinfovaldf, params)
    
    topobs(levelinfovaldf, params; n=20)
    
    plotinfovalbypermno(levelinfovaldf, params; drawname="top15", ntop=15)

    period = format(minimum(levelinfovaldf.date), "yyyymmdd") * "to" * format(maximum(levelinfovaldf.date), "yyyymmdd")

    # valid logs subsample
    lndf = completelogs(levelinfovaldf)
    lnlhs = [:lnVw, :lnrvw, :lnλpw]
    vcov = [Vcov.cluster(:date, :permno), Vcov.simple(), Vcov.simple()]
    vcovearn = [Vcov.cluster(:permno), Vcov.simple(), Vcov.simple()]

    # levels
    unit = :level

    @info "monthly time series levels plot ..."
    aggdf = cache(agg, "$(unit)_$(period)_lastdayofmonth", params, levelinfovaldf, lastdayofmonth; levelkwargs...)
    p = drawinfoval(aggdf, params, "month"; portfolios=false, shades=true)

    # logs
    unit = :log
    kwargs = (ys=lnlhs, vcov=vcov, levelkwargs...)
    kwargsearn = (ys=lnlhs, vcov=vcovearn, levelkwargs...)
    infovaldf = lndf
    drawfn = drawlninfoval

    @info "monthly time series logs plot ..."
    aggdf = cache(aggreg, "$(unit)_$(period)_lastdayofmonth", params, infovaldf, lastdayofmonth; kwargs...)
    p = drawfn(aggdf, params, "month"; portfolios=false, shades=true, terms=true, 
        xtitle="Month", dV=(x=-100,y=70), drv=(x=0,y=-40), dλ=(x=0, y=40))

    @info "COVID-19 crisis plots ..."
    aggdf = cache(aggreg, "$(unit)_$(period)_covid_identity", params, infovaldf, identity; mindate=Date(2019,11,1), kwargs...)
    drawfn(aggdf, params, "covid19"; portfolios = false, terms=true, 
        xtitle="Day", dV=(x=-100,y=50), drv=(x=0,y=-100))

    @info "2008 financial crisis plots ..."
    aggdf = cache(aggreg, "$(unit)_$(period)_fincrisis_identity", params, infovaldf, identity; mindate=Date(2007,1,1), maxdate=Date(2010,1,1), kwargs...)
    drawfn(aggdf, params, "fincrisis"; portfolios = false, terms=true, 
        xtitle="Day", dV=(x=-110,y=60), drv=(x=100,y=-150), dλ=(x=0,y=50))

    @info "Lehman failure plots ..."
    aggdf = cache(aggreg, "$(unit)_$(period)_lehman_identity", params, infovaldf, identity; mindate=Date(2008,9,15), maxdate=Date(2008,9,30), kwargs...)
    drawfn(aggdf, params, "lehman"; portfolios = false, terms=true, 
        xtitle="Day", dV=(x=-110,y=60), drv=(x=100,y=-150), dλ=(x=0,y=50))

    # Lehman notable results
    if !isempty(aggdf)
        ix18sep = findall(aggdf.date .== Date(2008,9,18))[1]
        ix19sep = findall(aggdf.date .== Date(2008,9,19))[1]
        lnpriceimpactdecline = -(aggdf.lnλpw[ix19sep] - aggdf.lnλpw[ix18sep])
        lnrvincrease = (aggdf.lnrvw[ix19sep] - aggdf.lnrvw[ix18sep])
        settexresults(params,
            "lnpriceimpactdecline"=>Formatting.format(lnpriceimpactdecline, precision=2),
            "lnrvincrease"=>Formatting.format(lnrvincrease, precision=2),
        )
    else
        @warn "No Lehman results because aggdf is empty. Is this a test subsample?"
    end

    @info "Seasonality plots ..."
    aggdf = cache(aggreg, "$(unit)_$(period)_week", params, infovaldf, week; kwargs...)
    p = drawfn(aggdf, params, "weekofyear"; terms=true, dλ=(x=0,y=-20),
        xtype="quantitative", xtitle="Week of year", dV=(x=-140,y=30), drv=(x=-115,y=-20))

    aggdf = cache(aggreg, "$(unit)_$(period)_dayofquarter", params, infovaldf, dayofquarter; kwargs...)
    p = drawfn(aggdf, params, "dayofquarter"; terms=true, dλ=(x=0,y=-20),
        xtype="quantitative", xtitle="Day of quarter", dV=(x=-140,y=70))

    aggdf = cache(aggreg, "$(unit)_$(period)_dayofweek", params, infovaldf, dayofweek; kwargs...)
    p = drawfn(aggdf, params, "dayofweek"; terms=true, dλ=(x=0,y=-20),
        xtype="ordinal", xtitle="Day of week", dV=(x=-140,y=30), drv=(x=-115,y=20))

    # try to reclaim some memory because it often fills up on the next step
    GC.gc()

    @info "time series size_bm portfolio plots ..."
    aggdf = cache(aggregxsxbm, "$(unit)_$(period)_lastdayofmonth", params, infovaldf, lastdayofmonth; kwargs...)
    drawfn(aggdf, params, "month_size_bm"; portfolios=true, shades=true, xtitle="Month")

    @info "Log Regressions ..."
    lnlhs = [:lnVw, :lnViw, :lnrvw, :lnλpw]

    # JLD currently cannot save and load anonymous functions without ReconstructedTypes
    # so this would fail at regtable() time. Thus, currently overriding cache
    regparams = paramsoverride(params, cachedata=false)

    @time regs(lndf, regparams, [:lnwtw]; lhs=lnlhs, levelkwargs...)
    @time regs(lndf, regparams, [:lnwtw, :bemew, :momretw]; lhs=lnlhs, levelkwargs...)
end 

# functions to produce figures and tables
using Printf: @sprintf, @printf

common_replacements = Vector{Pair{String,String}}()
# [push!(common_replacements, "$(var)_$(sub)"=>"\$$(var)_t^$(sub)\$") for var=[:icr,:logvar,:pd1yr,:biznewspres,:logVIX,:logVXO], sub=["0","+"]]
push!(common_replacements, "varname" => "Variable")
push!(common_replacements, "permno" => "Stock")
push!(common_replacements, "date" => "Date")
push!(common_replacements, "Vw" => "Information value, \\\$M")
push!(common_replacements, "Viw" => "Information value (intraday), \\\$M")
push!(common_replacements, "σw" => "Volatility")
push!(common_replacements, "σiw" => "Volatility (intraday)")
push!(common_replacements, "rvw" => "Return variance")
push!(common_replacements, "λpw" => "Price impact per \\\$M")
push!(common_replacements, "lag1close" => "Stock price")
push!(common_replacements, "lnwtw" => "Size (lnME)")
push!(common_replacements, "bemew" => "Book-to-market ratio")
push!(common_replacements, "momretw" => "Momentum")
push!(common_replacements, "ead" => "Earnings")
push!(common_replacements, "numest_excw" => "Analysts")
push!(common_replacements, "disp2w" => "Analyst Dispersion")
push!(common_replacements, "missing" => "~~~~~~~\\vdots")

function replabel(s, reps = common_replacements)
    for (k, v) in reps
      s = replace(s, k => v)
    end
    s
end

function nonsecol!(nextline, interleaveSEs)
    if interleaveSEs
        nextline *= " & "
    end
    nextline
end

function resultstable(resultsdir,resultsdf,resultsname;
    replacements = common_replacements,topheaders = [],fontsize = nothing,dataalign = "r",midrules = [],numfmt = "%5.3f",
    sedf = nothing, stars = false # df of same size as resultsdf of standard errors / pvalues placed in parentheses below point estimates
    )

    filename = joinpath(resultsdir, "$resultsname.tex")
    display(filename)
    fid = open(filename, "w");

    if !isnothing(fontsize)
        write(fid, "\\begin{$fontsize} \n")
    end

    rows, cols = size(resultsdf)
    colsyms = names(resultsdf)
    colnames = broadcast(string, colsyms)
    interleaveSEs = !isnothing(sedf)
    # presented_cols = interleaveSEs ? cols - sum(broadcast(isSEcol,colnames)) : cols
    @printf(fid,"\\begin{tabular*}{1\\columnwidth}{@{\\hskip\\tabcolsep\\extracolsep\\fill}l*{%u}{%s}}\n",cols - 1,dataalign)
    write(fid, "\\toprule \n")

    for topheader in topheaders
        write(fid, topheader)
        # write(fid, " \\\\ \n")
    end

    # print column labels
    first = true
    for colname = colnames
        collabel = replabel(colname, replacements)
        if first
            first = false
            write(fid, " \\multicolumn{1}{l}{$collabel}")
        else
            write(fid, " & \\multicolumn{1}{c}{$collabel}")
        end
    end
    write(fid, " \\\\ \n")
    write(fid, "\\midrule \n")

    # print rows
    for r = 1:rows
        if r in midrules
            write(fid, "\\midrule \n")
        end
        nextline = ""
        for c = 1:cols
            colname = colnames[c]
            if colname in ["models", "varname", "variable", "date"]
            value = replabel(string(resultsdf[r,c]), replacements)
            elseif lowercase(colname) == "obs"
            # value = @sprintf("%u",resultsdf[r,c])
            value = sprintf1("%'u", resultsdf[r,c])
            write(fid, " &")
            nonsecol!(nextline, interleaveSEs)
            elseif colname == "γ"
            value = @sprintf("%u",resultsdf[r,c])
            write(fid, " &")
            nonsecol!(nextline, interleaveSEs)
            elseif ismissing(resultsdf[r,c])
            value = ""
            write(fid, " &")
            nonsecol!(nextline, interleaveSEs)
            elseif typeof(resultsdf[r,c]) <: Number
            value = sprintf1(numfmt, resultsdf[r,c])
            if stars
                value = latex_estim_decoration(value, sedf[r,colsyms[c]])
            else
                value *= "~"
            end
            write(fid, " & ")
            if interleaveSEs
                # use col sym to make sure the point estimate matches with se stat
                csym = colsyms[c]

                if typeof(sedf[r,csym]) <: Number
                    sevalue = sprintf1(numfmt, sedf[r,csym])
                    nextline *= " & ($sevalue)"
                else
                    nextline *= " & "
                end
            end
        else
            value = resultsdf[r,c]
            write(fid, " &")
            nonsecol!(nextline, interleaveSEs)
        end
        write(fid, " $value")
      end
      write(fid, " \\\\ \n")
        if interleaveSEs && !isempty(strip(nextline, ['&','\\',' ']))
            write(fid, "$nextline \\\\ \n")
        end
    end

    write(fid, "\\bottomrule \n")
    write(fid, "\\end{tabular*} \n")
    if !isnothing(fontsize)
        write(fid, "\\end{$fontsize} \n")
    end
    close(fid)

    filename
end

function StatsBase.summarystats(infovaldf::DataFrame, params::Params; prefix="summarystats")
    sscols = [:Vw, :Viw, :σw, :σiw, :λpw, :lag1close, :lnwtw, :bemew, :momretw]
    ssdf = describe(infovaldf[:, sscols], :Mean=>mean, :Std=>std, :Min=>minimum, :q25, :Median=>median, :q75, :Max=>maximum, :Obs=>length)

    ssdf[sscols.==:Vw, :Mean] .= meanratio(infovaldf.rvw, infovaldf.λpw)
    ssdf[sscols.==:Vw, :Std] .= sqrt(varratio(infovaldf.rvw, infovaldf.λpw, infovaldf.date))
    rviw = infovaldf.σiw .^2
    ssdf[sscols.==:Viw, :Mean] .= meanratio(rviw, infovaldf.λpw)
    ssdf[sscols.==:Viw, :Std] .= sqrt(varratio(rviw, infovaldf.λpw, infovaldf.date))

    startyyyymm = minimum(infovaldf.yyyymm)
    endyyyymm = maximum(infovaldf.yyyymm)
    resname = "$(prefix)$(params)_$(startyyyymm)_$(endyyyymm)"
    resultstable(tbldir(), ssdf, resname; numfmt = "%'3.2f")
    ssdf
end

function topobs(infovaldf::DataFrame, params::Params; n=10)
    # agg by day
    aggdf = agg(infovaldf, identity)

    # sort by value of information
    ix = sortperm(aggdf.Vw)
    resdf = aggdf[ix[end:-1:end-n+1], [:date, :Vw, :rvw, :λpw]]
    allowmissing!(resdf)
    push!(resdf, (date=missing, Vw=missing, rvw=missing, λpw=missing))
    append!(resdf, aggdf[ix[n:-1:1], [:date, :Vw, :rvw, :λpw]])

    # topobs table
    startyyyymm = minimum(infovaldf.yyyymm)
    endyyyymm = maximum(infovaldf.yyyymm)
    resname = "topobs$(params)_$(startyyyymm)_$(endyyyymm)"
    resultstable(tbldir(), resdf, resname; numfmt="%'3.2f")

    # notable results
    topadate = format(resdf.date[1], "E, U d, Y")
    topaVwUSDm = Formatting.format(resdf.Vw[1], precision=1)
    topadailyUSDk = Formatting.format(resdf.Vw[1] / 252 * 10^3, precision=0)
    topbdate = format(resdf.date[2], "E, U d, Y")
    topbVwUSDm = Formatting.format(resdf.Vw[2], precision=1)
    topbdailyUSDk = Formatting.format(resdf.Vw[2] / 252 * 10^3, precision=0)
    
    settexresults(params,
        "topadate"=>topadate,
        "topaVwUSDm"=>topaVwUSDm,
        "topadailyUSDk"=>topadailyUSDk,
        "topbdate"=>topbdate,
        "topbVwUSDm"=>topbVwUSDm,
        "topbdailyUSDk"=>topbdailyUSDk,
    )

    resdf
end

"Returns portfolio assignment number for x given quantile breakpoints qbp"
function qport(x, qbp)
    n = length(qbp)
    for i=1:n
        qi = qbp[i]
        if x <= qi
            return i
        end
    end    
    n + 1
end

function up95(v)
    m = mean(v)
    n = length(v)
    se = std(v) / sqrt(n)
    m + 1.96*se
end

function bt95(v)
    m = mean(v)
    n = length(v)
    se = std(v) / sqrt(n)
    m - 1.96*se
end

function robustdf(v::Symbol; test=false,
    approaches = [:flam, :PercentPriceImpact_][1:1], 
    dirs = [:CLNV, :LR, :EMO])

    ps = allparams(approaches=approaches, dirs=dirs)

    robust = DataFrame(params=Params[], specname=String[], mu=Float64[], up95=Float64[], bt95=Float64[])

    specnum = 0
    for params in ps
        @info "loading infovaldf for $p"
        specnum += 1
        infovaldf = loadclean(params)
        x = infovaldf[!, v]
        μ = mean(x)
        n = length(x)
        σ = std(x)
        se = σ / sqrt(n)
        up95 = μ + 1.96*se
        bt95 = μ - 1.96*se

        push!(robust, (params=params, specname=specname(specnum, params), mu=μ, up95=up95, bt95=bt95))
    end

    robust
end

function robustVw(; test=false,
    approaches = [:flam, :PercentPriceImpact_][1:1], 
    dirs = [:CLNV, :LR, :EMO])

    ps = allparams(approaches=approaches, dirs=dirs)

    robust = DataFrame(params=Params[], specname=String[], mu=Float64[], up95=Float64[], bt95=Float64[])

    specnum = 0
    for params in ps
        @info "loading infovaldf for $params"
        specnum += 1
        infovaldf = loadclean(params)
        μ = meanratio(infovaldf.rvw, infovaldf.λpw)
        up95 = up95ratio(infovaldf.rvw, infovaldf.λpw, infovaldf.date)
        bt95 = bt95ratio(infovaldf.rvw, infovaldf.λpw, infovaldf.date)

        push!(robust, (params=params, specname=specname(specnum, params), mu=μ, up95=up95, bt95=bt95))
    end

    robust
end

function robustregcoef(lhs::Symbol, rhs::Vector{Symbol}, period::String; 
    approaches = [:flam, :PercentPriceImpact_][1:1], 
    dirs = [:CLNV, :LR, :EMO],
    v = Vcov.cluster(:date, :permno),
    test = false,
    cachekwargs...)

    ps = allparams(;approaches=approaches, dirs=dirs, test=test)

    robust = DataFrame(params=Params[], specname=String[], 
        coefsym=Symbol[], coefname=String[], 
        mu=Float64[], up95=Float64[], bt95=Float64[])

    r = term.(rhs)
    fes0 = @formula(1 ~ 1 + fe(date) + fe(permno)).rhs
    fes = [fes0[1:1], fes0[2:2], fes0[3:3], fes0[2:3]]
    fenames = ["No FE", "Date FE", "Stock FE", "Date and Stock FE"]

    specnum = 0
    for i = 1:length(fes)
        for params in ps
            @info "loading regressions for $params"
            specnum += 1
            fe = fes[i]
            spec = string(specname(specnum, params), ", ", fenames[i])
            f = term(lhs) ~ sum((r..., fe...))
            @info "f: $f"
            @assert incache(reg, regname(f,v,period), params) "reg $(regname(f,v,period)) for $params not found in cache."
            m = cache(reg, regname(f,v,period), params, DataFrame(), f, v; cachekwargs...)
            β = coef(m)
            ci = confint(m)
            cnames = coefnames(m)
            for c = 1:length(β)
                push!(robust, (params=params, specname=spec, 
                    coefsym=Symbol(cnames[c]), coefname=labels[cnames[c]], 
                    mu=β[c], bt95=ci[c,1], up95=ci[c,2]))
            end
        end
    end

    robust
end

function plotrobustcoef(robust::DataFrame, rhsvar::Symbol; kwargs...)
    robust = robust[robust.coefsym.==rhsvar,:]
    plotrobust(robust, xtitle=string(labels[string(rhsvar)], " coefficient"); kwargs...)
end

function plotrobust(df::DataFrame; 
        xtitle = "",
        drawname = nothing
    )
    p = df |>
    @vlplot(y = {field=:specname, type=:nominal, title="Specification", sort=false, 
            axis={orient="right"}}, 
        config = {
            font = "Utopia"
        }
    ) +
    @vlplot(
        mark={type=:errorbar,ticks=true},
        encoding = {
            x = {
                "up95:q",
                title = "Value of information, USD millons per year",
                scale = {zero=false}
            },
            x2 = {
                "bt95:q"
            },
        },
        width = 250,
        height = 200
    ) +
    @vlplot(
        mark={
            :point,
            filled=true
        },
        x = :mu
    )

    if !isempty(xtitle)
        p.layer[1]["encoding"]["x"]["title"] = xtitle
    end

    if !isnothing(drawname)
        figfile = joinpath(figdir(), "robust_$(drawname).pdf")
        p |> save(figfile)
        @info "drew robustness plot to $figfile"
    end

    p
end

function winsorrobustness(df::DataFrame, params::Params; pwinsors=1:5)
    @assert issorted(pwinsors) "pwinsors must be sorted in ascending order."
    rvw = copy(df.rvw)
    λpw = copy(df.λpw)
    cluscol = df.date

    Vw = Float64[]
    VwUp95 = Float64[]
    VwBt95 = Float64[]
    meanrvw = Float64[]
    meanλpw = Float64[]

    for p in pwinsors
        @info "winsorizing at $p percentile"
        winsor!(rvw, prop=p/100)
        winsor!(λpw, prop=p/100)

        @info "calculating mean at $p percentile"
        push!(Vw, meanratio(rvw, λpw))

        @info "calculating up95 at $p percentile"
        push!(VwUp95, up95ratio(rvw, λpw, cluscol))

        @info "calculating bt95 at $p percentile"
        push!(VwBt95, bt95ratio(rvw, λpw, cluscol))

        @info "calulating mean rvw and λpw at $p percentile"
        push!(meanrvw, mean(rvw))
        push!(meanλpw, mean(λpw))
    end
    
    winsordf = DataFrame(pwinsor=pwinsors, Vw=Vw, VwUp95=VwUp95, VwBt95=VwBt95, meanrvw=meanrvw, meanλpw=meanλpw)

    p = winsordf |>
        @vlplot(x = {field = :pwinsor, title = "Winsorization percentile"},
            config = {
                font = "Utopia",
            }
        ) +
        @vlplot(
            mark = {type = :errorbar, ticks = true},
            encoding = {
                y = {
                    "VwUp95:q",
                    title = "Value of information, USD millons per year (95% CIs)"
                },
                y2 = {
                    "VwBt95:q"
                },
            },
            width = 250,
            height = 200
        ) +
        @vlplot(
            mark = {
                :point,
                filled = true
            },
            y = :Vw
        )

    figfile = joinpath(figdir(), "robust_pwinsor_Vw.pdf")
    p |> save(figfile)
    @info "drew first pwinsor robustness plot to $figfile"
    
    rvλdf = stack(
        rename(winsordf, "meanrvw" => "Return Variance", "meanλpw" => "Price Impact")
        , ["Return Variance", "Price Impact"], [:pwinsor]
    )

    p = rvλdf |>
        @vlplot(:circle,
                x = {field = :pwinsor, title = "Winsorization percentile"},
                config = {
                    font = "Utopia",
                },
                y = {field=:value, title="Winsorized mean"},
                color = {field = :variable, title = nothing, legend={orient="bottom-left"}},
                width = 250,
                height = 200,
            )
            
    figfile = joinpath(figdir(), "robust_pwinsor_rv_and_lambda.pdf")
    p |> save(figfile)
    @info "drew second pwinsor robustness plot to $figfile"

    winsordf
end

function robustness(; period = "2003911to20201231", kwargs...)
    # baseline params
    params = Params()

    @info "Notable results ..."
    # note it is assumed noteable results only uses cached results
    infovaldf = loadclean(params)
    noteableresults(infovaldf, params)

    # winsor robustness doesn't rely on param variation, but rather 
    # takes the data in the benchmark params and applies winsorization
    # at different levels to make a plot of Vw against pwinsor
    winsorrobustness(infovaldf, params)

    # spec name
    startyyyymm = minimum(infovaldf.yyyymm)
    endyyyymm = maximum(infovaldf.yyyymm)
    samplesuffix = "$(params)_$(startyyyymm)_$(endyyyymm)"

    # regressions
    lhs = :lnVw
    rhs = [:lnwtw, :bemew, :momretw]
    

    # all coefs and their CIs in a dataframe
    robust = robustregcoef(lhs, rhs, period; kwargs...)

    # draw figures
    for r in rhs
        plotrobustcoef(robust, r; drawname="regcoef_$r$samplesuffix")
    end

    # means and CIs in a dataframe
    robust = robustVw(; kwargs...)
    plotrobust(robust; drawname="mean_Vw$samplesuffix")

    @info "Multiple Informed Plots ..."
    plotfn(c)
    plotfρ(c)

    plotfn(cpc)
    plotfρ(cpc)

    plotfn(c, ρs=0:0, ns=1:20)
    plotfn(cpc, ρs=0:0, ns=1:20) 

    plotfρ(c, ns=2:2)
    plotfρ(cpc, ns=2:2)

    plotisoq()
end

function plotinfovalbypermno(infovaldf, params::Params; ntop=10, drawname = nothing, 
    label=:symbol,          # variable to use for text labels
    yvar=:Vw,                # Vw or Vwhat
    datefun=lastdayofmonth
    )
    
    # means by permno
    if yvar == :Vw
        @info "simple aggregation of infoval by permno"
        valuebypermno = combine(groupby(infovaldf, :permno), 
            [:rvw, :λpw] => meanratio => :Vw, 
            :wt=>(x->mean(x)/10^6)=>:wtbil,
            :symbol=>last=>:symbol)
    elseif yvar == :Vwhat
        regdf = infovaldf[!, [:permno, :Vw, :wt, :symbol]]
        regdf.date = datefun.(infovaldf.date)

        @info "regressing infoval on $(datefun)(date) and permno FEs"
        f = @formula(Vw ~ 1 + fe(date) + fe(permno))
        m = reg(regdf, f, save=:all)

        # FE dataframe 
        mdf = [regdf fe(m)]
        mdf.ϵ = residuals(m)
        @assert all(map((x,y)->(ismissing(y) || isapprox(x,y;atol=1e-6)), mdf.Vw, mdf.fe_date + mdf.fe_permno + mdf.ϵ)) "Vw != fe_date + fe_permno + ϵ"

        meandatefe = mean(skipmissing(mdf.fe_date))
        valuebypermno = combine(groupby(mdf, :permno), 
            :fe_permno=>first=>:fe_permno, 
            :wt=>(x->mean(x)/10^6)=>:wtbil,
            :symbol=>last=>:symbol)
        valuebypermno.Vwhat = valuebypermno.fe_permno .+ meandatefe
        dropmissing!(valuebypermno, :Vwhat)
    else
        error("unknown yvar $yvar")
    end

    # sort by value of info
    sort!(valuebypermno, yvar, rev=true)
    
    # set labels only for ntop value firms to keep legible
    nfirms = size(valuebypermno , 1)
    valuebypermno.text = fill("", nfirms)
    ixlabeled = 1:ntop
    valuebypermno.text[ixlabeled] = valuebypermno[ixlabeled, label]

    # plot
    p = valuebypermno |>
        @vlplot(x = {field=:wtbil, title="Market equity, USD billions"}, 
            config = {
                font = "Utopia",
            }
        ) +
        @vlplot(
            :circle,
            y = {yvar, title = "Value of information, USD millons per year"},
            width = 400,
            height = 300
        ) +
        @vlplot(
            mark={
                :text,
                align=:left,
                baseline=:middle,
                dx=5
            },
            encoding={y = yvar},
            text="text:n"
        )

    if !isnothing(drawname)
        figfile = joinpath(figdir(), "$(yvar)_bypermno$(params)_$(drawname).pdf")
        p |> save(figfile)
        @info "drew robustness plot to $figfile"
    end

    p, valuebypermno
end

resultstexfile(params::Params) = joinpath(tbldir(), "noteableresults$params.tex")
function writetexresults(params::Params, results::Dict)
    open(resultstexfile(params), "w") do io
        println(io, "% This file is automatically generated by analysis.jl:writetexresults()")
        write(io,"\n")

        for (key, value) in results
            write(io, "\\newcommand{\\")
            write(io, key)
            write(io, "}{")
            print(io, value)
            write(io, "}\n")
        end
    end
end

function readtexresults(params::Params)
    results = Dict{String, Any}()

    if !isfile(resultstexfile(params))
        @warn "resultstexfile does not exist at $(resultstexfile(params))"
        return results
    end

    open(resultstexfile(params), "r") do io
        # first two lines are header
        readline(io)
        readline(io)

        for l in readlines(io)
            splitline = split(l, ['{', '\\', '}'])
            key = splitline[4]
            value = splitline[6]
            results[key] = value
        end
    end

    results
end

function settexresults(params, rs::Pair...)
    # read existing results
    results = readtexresults(params)

    # add new results overwriting old ones if there
    newresults = Dict(rs)
    merge!(results, newresults)

    # write all results to disk
    writetexresults(params, results)
end
