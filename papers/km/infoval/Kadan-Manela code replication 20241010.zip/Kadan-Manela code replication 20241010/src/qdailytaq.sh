#!/bin/bash
# e.g.
# ./qdailytaq.sh 20031001 20031101 test
# ./qdailytaq.sh 20031001 20200225 full
STARTDATE=$1 #"20031001"
ENDDATE=$2 #"20200225"
SUBSAMPLE=$3 #"full"

#make directories
TAQHOME=/home/wustl/amanela/taq

mkdir -p $TAQHOME
mkdir -p /scratch/wustl/amanela/taq
mkdir -p $TAQHOME/data
mkdir -p $TAQHOME/ge_logs
mkdir -p $TAQHOME/ge_errs
mkdir -p $TAQHOME/sas_logs

# queue monthly jobs
# while [ $YYYY -lt $ENDYEAR -o $MM -le $ENDMONTH ] 
find /wrds/nyse/sasdata/taqms/nbbo -name "nbbom_*.sas7bdat" | egrep -o '20[[:digit:]]+' | while read -r YYYYMMDD ; do 
    if [ $YYYYMMDD -gt $STARTDATE -a $YYYYMMDD -le $ENDDATE ]; then

        LOGFILE=sas_logs/dailytaq.$YYYYMMDD.log

        if [ -f "$LOGFILE" ]; then

            # if grep -q "ERROR:" $LOGFILE; then
            if grep -q -P '^((?=.*ERROR:)(?!.*valid)(?!.*Errors printed))' $LOGFILE ; then
                echo "Retrying Job at `date`: $YYYYMMDD $SUBSAMPLE"        
                qsub -v DATEPREFIX=$YYYYMMDD,SUBSAMPLE=$SUBSAMPLE dailytaqjob.sh
            # else
                # skipping
            fi
        else
            echo "Queuing Job at `date`: $YYYYMMDD $SUBSAMPLE"
            qsub -v DATEPREFIX=$YYYYMMDD,SUBSAMPLE=$SUBSAMPLE dailytaqjob.sh
        fi
    fi
done
