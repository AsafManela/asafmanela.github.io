#!/bin/bash
#$ -cwd
#$ -m abe
#$ -M amanela@wustl.edu
#$ -o ge_logs/
#$ -e ge_errs/
echo "Starting Job at `date`: $DATEPREFIX $SUBSAMPLE"
sas dailytaq.sas -log sas_logs/dailytaq.$DATEPREFIX.log
echo "Ending Job at `date`: $DATEPREFIX $SUBSAMPLE"