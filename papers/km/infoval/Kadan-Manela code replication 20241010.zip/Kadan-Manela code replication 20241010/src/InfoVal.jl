module InfoVal

using Statistics: mean, std, var, cov
import Dates
using Dates: Date, Year, epochdays2date, month, year, lastdayofmonth, Time, Minute,
    dayofyear, dayofquarter, dayofweek, dayname, week, format, @dateformat_str
using VegaLite: @vlplot, @vl_str
using Setfield: @set
using StatFiles: load
using Query: @take
using DataFrames: DataFrame, describe, disallowmissing!, select!, Not, transform!,
    rename!, rename, dropmissing, dropmissing!, categorical, by, missings, nonunique,
    innerjoin, leftjoin, combine, groupby, append!, allowmissing!, AbstractDataFrame, stack
using CategoricalArrays: levels, ordered!
import CategoricalArrays
using FileIO
using JLD2
import CSV
using FixedEffectModels, RegressionTables, StatsModels #, CuArrays
import StatsBase
using StatsBase: summarystats, percentile, median, CovarianceEstimator
using Formatting: sprintf1
import Formatting
import QuantileRegressions: qreg
import QuantileRegressions
# using CuArrays
using ExtractMacro: @extract
import CovarianceMatrices
using CovarianceMatrices: lrvar, CRHC1
export datadir, wrdsdir, figdir, tbldir, 
    infoval, loaddata, loadclean, Params, analyze,
    plotc

using Base: @kwdef
using ExcelFiles
using SpecialFunctions: expint, expintx
import ZipFile
using Roots: find_zero, find_zeros, Bisection

include("consts.jl")
include("params.jl")
include("leadlag.jl")
include("loaddata.jl")
include("analysis.jl")
include("multipleinformed.jl")

end # module
