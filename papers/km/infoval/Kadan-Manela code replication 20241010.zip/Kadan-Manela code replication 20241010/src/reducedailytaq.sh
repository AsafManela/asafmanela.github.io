#!/bin/bash
echo "Reducing Daily TAQ monthly results to full sample files ..."
qsas reducedailytaq.sas
