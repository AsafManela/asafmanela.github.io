#!/bin/bash
echo "Downloading new data from wrds ..."
# sftp wrds-cloud.wharton.upenn.edu:taq/data/infoval.sas7bdat ~/Dropbox/KadanManela/InfoVal/data/taq
rsync -avu $1 -e "ssh -q" "amanela@wrds-cloud.wharton.upenn.edu:/scratch/wustl/amanela/taq/" "$HOME/Dropbox/KadanManela/InfoVal/data/taq/daily/"
echo "Done."