# plots for the case of multiple informed investors
cζ(n,ζ) = exp(ζ) * expint(2/n, ζ)

ϕ(n, ρ) = 1/n + (n-1)/n * ρ

ζ(n, ϕ) = (1-ϕ) / (n*ϕ)

"""
Constant of proportionality for combined value of information 
when there are `n` informed investors and `ρ` is the correlation
of their signals.
"""
c(n, ρ) = cζ(n, ζ(n, ϕ(n, ρ)))

"""
Constant of proportionality for per capital value of information 
when there are `n` informed investors and `ρ` is the correlation
of their signals.
"""
cpc(n, ρ) = c(n, ρ) / n

"""
Find the value of the function c(n, ρ) for a given `n` and `ρ`.
"""
function ρ(n, c0; ϵ=1e-3)
    f = ρ -> (c(n, ρ) - c0) 
    find_zero(f, (ϵ, 1.0-ϵ), Bisection(), verbose=true)
end

κζ(n, ζ) = expint(4/n-2, 2*ζ)

κ(n, ρ) = κζ(n, ζ(n, ϕ(n, ρ)))

β(n, ρ, t) = 1 - 1/κ(n, ρ)

# Define functions based on these equations
# \[
# \beta \left( t\right) =\sigma _{z}\left( \frac{\kappa }{\Sigma \left(
# 0\right) }\right) ^{\frac{1}{2}}\left( \frac{\Sigma \left( t\right) }{\Sigma
# \left( 0\right) }\right) ^{\frac{n-2}{n}}\exp \left[ \zeta \frac{\Sigma
# \left( 0\right) }{\Sigma \left( t\right) }\right] , 
# \]%
# \[
# \alpha \left( t\right) =-\beta \left( t\right) /n, 
# \]%
# and

# \[
# \lambda \left( t\right) =\frac{\beta \left( t\right) \Sigma \left( t\right) 
# }{\sigma _{z}^{2}}, 
# \]%
function β(n, ρ, σz, σv, t) 
    Σ0 = Σ(0, σz, σv)
    Σt = Σ(t, σz, σv)

    σz * (κ(n, ρ) / Σ0)^0.5 * (Σt / Σ0)^(n-2)/n * exp(ζ(n, ϕ(n, ρ)) * Σ0 / Σt)
end

α(n, ρ, σz, σv, t) = -β(n, ρ, σz, σv, t) / n

Σ(t, σz, σv) = throw(ArgumentError("Σ(t, σz, σv) not implemented"))

λ(n, ρ, σz, σv, t) = β(n, ρ, σz, σv, t) * Σ(t, σz, σv) / σz^2

"""
The combined value of information relative to the Kyle
value of information (σ_v * σ_z)
(var(v) and σ_Z are assumed to be 1),
when there are `n` informed investors and `ρ` is the correlation
of their signals.
"""
Ω(n, ρ) = sqrt(1/κ(n, ρ)) * expint(2/n, ζ(n, ϕ(n, ρ)))


"""
The per-capita value of information relative to the Kyle
value of information (σ_v * σ_z)
(var(v) and σ_Z are assumed to be 1),
when there are `n` informed investors and `ρ` is the correlation
of their signals.
"""
Ωpc(n, ρ) = Ω(n, ρ) / n


"""
Price impact coefficient
(var(v) and σ_Z are assumed to be 1),
when there are `n` informed investors and `ρ` is the correlation
of their signals.
"""
λ(n, ρ) = sqrt(κ(n, ρ)) * exp(ζ(n, ϕ(n, ρ)))

# another way to get it for verification:
# λb(n, ρ) = c(n,ρ) / Ω(n,ρ)

function ylabel(f::Function, ns, ρs)
    fstr = string(f)
    suffix = ""

    n = (length(ns) == 1) ? first(ns) : "n"
    ρ = (length(ρs) == 1) ? first(ρs) : "ρ"

    if endswith(fstr, "pc")
        fstr = replace(fstr, "pc" => "")
        # fstr = fstr[1:(end-2)]
        suffix = " / $n"
    end

    if isa(n, Number)
        n = "n=$n"
    end

    if isa(ρ, Number)
        ρ = "ρ=$ρ"
    end

    string(fstr, "($n,$ρ)", suffix)
end

function figfile(xvar, filesuffix, f, ns, ρs)
    fun = replace(ylabel(f,ns,ρs), " "=>"_")
    fun = replace(fun, "/"=>"over")
    fun = replace(fun, "("=>"[")
    fun = replace(fun, ")"=>"]")
    joinpath(figdir(), "$(fun)_as_fun_of_$xvar.$filesuffix")
end

function plotfn(f::Function; ns=1:50, ρs=0.01:0.01:0.9)
    df = DataFrame(n=Int[], ρ=Float64[], value=Float64[])

    for n=ns, ρ=ρs
        push!(df, (n, ρ, f(n, ρ)))
    end

    p = df |>
    @vlplot(x = {field=:n, title="Number of Informed, n"}, 
        config = {
            font = "Utopia",
        }
    ) 
    
    if length(ρs) == 1
        p = p +
        @vlplot(
            :line,
            y = {field=:value, title=ylabel(f,ns,ρs)},
            width = 300,
            height = 200
        )
    else
        p = p +
        @vlplot(
            :line,
            y = {field=:value, title=ylabel(f,ns,ρs)},
            color = {field=:ρ, title="Signal Correlation, ρ"},
            width = 300,
            height = 200
        )
    end

    
    p |> save(figfile("n", "pdf", f, ns, ρs))
    # p |> save(figfile("n", "png", f, ns, ρs))

    @info "drew infoval to $(figfile("n", "pdf", f, ns, ρs))"

    p
end

function plotfρ(f::Function; ns=1:50, ρs=0.01:0.01:0.9)
    df = DataFrame(n=Int[], ρ=Float64[], value=Float64[])

    for n=ns, ρ=ρs 
        push!(df, (n, ρ, f(n, ρ)))
    end

    p = df |>
    @vlplot(x = {field=:ρ, title="Signal Correlation, ρ"}, 
        config = {
            font = "Utopia",
        }
    ) 
    
    if length(ns) == 1
        p = p +
        @vlplot(
            :line,
            y = {field=:value, title=ylabel(f,ns,ρs)},
            width = 300,
            height = 200
        )
    else
        p = p +
        @vlplot(
            :line,
            y = {field=:value, title=ylabel(f,ns,ρs)},
            color = {field=:n, title="Number of Informed, n"},
            width = 300,
            height = 200
        )
    end

    p |> save(figfile("rho", "pdf", f, ns, ρs))
    # p |> save(figfile("n", "png", f, ns, ρs))

    @info "drew infoval to $(figfile("rho", "pdf", f, ns, ρs))"

    p
end

# isoquant plot
function plotisoq(; ns=2:10, cs=[1.0000, 1.01,1.05,1.08])
    df = DataFrame(n=Int[], c=Float64[], ρ=Float64[])

    for n=ns, c=cs
        ρnc = ρ(n,c)
        push!(df, (n, c, ρnc))
        @info "Iteration: " (n, c, ρnc)
    end

    p = df |>
    @vlplot(:line,
        x = {field=:n, title="Number of Informed, n"}, 
        y = {field=:ρ, title="Signal Correlation, ρ"},
        color = {field=:c, title="c(n,ρ)", type="ordinal"},
        config = {
            font = "Utopia",
        },
        width = 300,
        height = 200
    )

    ff = figfile("n", "pdf", ρ, ns, cs)

    p |> save(ff)
    # p |> save(figfile("n", "png", f, ns, 0.01:0.01:0.9))

    @info "drew infoval to $(ff)"

    p
end
