#!/bin/bash
echo "Uploading src/$1 code to wrds ..."
echo "put /home/amanela/.julia/dev/InfoVal/src/$1" | sftp -q wrds-cloud.wharton.upenn.edu:taq/
echo "Done."