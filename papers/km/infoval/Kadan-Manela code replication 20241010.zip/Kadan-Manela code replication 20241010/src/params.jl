"Struct holding parameters / choices for later robustness tests"
@kwdef mutable struct Params
    approach::Symbol = :flam    # calculation of price impact (λ)
    weighting::String = ""      # weighting scheme when approach=:PercentPriceImpact_
    dir::Symbol = :CLNV         # algorithm for signing trades
    minprice::Int = 5           # minimum stock price to be considered in analysis
    test::Bool = false          # whether using only test subset of sample
    cachedata = true            # whether to cache data and results
    infladj = true              # whether to adjust prices for inflation
    rvbenchmark::String = ""    # if not empty, subtract from each stock's rv this benchmark symbol's rv 
end

function paramsoverride(params::Params; kwargs...)
    newparams = deepcopy(params)

    for (k, v) in pairs(kwargs)
        setfield!(newparams, k, v)
    end

    newparams
end

λvar(p::Params) = Symbol(p.approach, p.dir, p.weighting)

valuestring(::Nothing) = ""
valuestring(x::Bool) = string(Int(x))
valuestring(x) = strip(string(x), '_')

function Base.show(io::IO, p::Params)
    # print all fields except cachedata
    fields = filter(!isequal(:cachedata), fieldnames(Params))
    for f in fields
        k = string(f)[1]
        v = getfield(p, f)
        vstr = valuestring(v)
        if (f != :rvbenchmark) || (length(p.rvbenchmark) > 0)
            print(io, "_$k$vstr")
        end
    end
end

"All param specifications"
function allparams(; test = false, cachedata = true,
    approaches = [:flam, :PercentPriceImpact_], 
    dirs = [:CLNV, :LR, :EMO])

    ps = Params[]

    jobs = vec([(approach, dir) for dir in dirs, approach in approaches])

    for (approach,dir) in jobs
        if approach in [:testlam, :lam, :flam]
            weighting = [""]
        else
            weighting = ["_Ave", "_SW", "_DW"][3:3]
        end
    
        for w in weighting
            p = Params(
                approach=approach, 
                weighting=w, 
                dir=dir,
                test=test,
                cachedata=cachedata
                )

            push!(ps, p)
        end
    end

    # what if we don't eliminate penny stocks?
    push!(ps, Params(minprice=0, test=test, cachedata=cachedata))

    # what if we subtracted SPY rv?
    push!(ps, Params(rvbenchmark="SPY", test=test, cachedata=cachedata))

    ps
end 


function specname(specnum, params::Params)
    s = string(λvar(params))

    # we currently only show flam
    s = replace(s, "flam"=>"")

    # s = replace(s, "flam"=>"Fixed interval λ, ")
    # s = replace(s, "PercentPriceImpact_"=>"Single-trade based λ, ")

    if params.minprice == 0
        s = "No minimum price"
    end

    if params.rvbenchmark == "SPY"
        s = "Idiosyncratic variance"
    end

    string("($specnum) ", s)
end
