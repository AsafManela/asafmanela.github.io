#!/bin/bash
echo "Running all analysis"
echo "NOTE: some of the heavier regressions require over 200GB of RAM!"
LOGDIR="$HOME/Dropbox/KadanManela/InfoVal/log"
mkdir -p $LOGDIR
nohup julia +1.7 -O 3 --project=`pwd` src/runall.jl > $LOGDIR/runall.err.log &
