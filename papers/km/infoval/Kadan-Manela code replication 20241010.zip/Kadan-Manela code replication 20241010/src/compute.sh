#!/bin/bash

##########################################################################
# script to run a julia script on a compute node within a docker instance
##########################################################################

JLSCRIPT=$1
EXTRAPARAMS=${@:2}
LOGDIR="$STORAGE1/ManelaLab/InfoVal/log"

echo "compute.sh called with JLSCRIPT=$JLSCRIPT, EXTRAPARAMS=$EXTRAPARAMS, LOGDIR=$LOGDIR"

mkdir -p $LOGDIR

cd $PROJDIR/src

if [ -z "$LSB_DJOB_NUMPROC" ]
then
      let "NUMWORKERS = `nproc` - 2"
else
      let "NUMWORKERS = $LSB_DJOB_NUMPROC - 1"
fi

[ ! -z "$LSB_JOBID" ] || LSB_JOBID="0"

ERRLOG=$LOGDIR/$JLSCRIPT.$LSB_JOBID.$HOSTNAME.err.log

echo "running $JLSCRIPT.jl with $NUMWORKERS parallel workers..."

[ -e $ERRLOG ] || touch $ERRLOG

export JULIA_PROJECT=$PROJDIR; julia -p $NUMWORKERS $JLSCRIPT.jl >> $ERRLOG $EXTRAPARAMS

echo "$JLSCRIPT.jl completed."
