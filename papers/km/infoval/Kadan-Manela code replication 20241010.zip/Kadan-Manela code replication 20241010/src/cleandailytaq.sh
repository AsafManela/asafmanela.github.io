#!/bin/bash
echo "Cleaning up scratch temporary results ..."
rm -rf /scratch/wustl/amanela/taq

echo "Cleaning up logs ..."
rm -rf /home/wustl/amanela/taq/data/*
rm -rf /home/wustl/amanela/taq/ge_errs/*
rm -rf /home/wustl/amanela/taq/ge_logs/*
rm -rf /home/wustl/amanela/taq/sas_logs/*

echo "Done cleaning."
