#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct  6 11:47:01 2019

@author: iris
"""

#####################################
# ICLINK: Link CRSP and IBES        #
# June 2019                         #
# Qingyi (Freda) Song Drechsler     #
#####################################

# This program replicates the SAS macro ICLINK 
# to create a linking table between CRSP and IBES
# Output is a score reflecting the quality of the link
# Score = 0 (best link) to Score = 6 (worst link)
# 
# More explanation on score system:
# - 0: BEST match: using (cusip, cusip dates and company names)       
#          or (exchange ticker, company names and 6-digit cusip)     
# - 1: Cusips and cusip dates match but company names do not match    
# - 2: Cusips and company names match but cusip dates do not match    
# - 3: Cusips match but cusip dates and company names do not match    
# - 4: tickers and 6-digit cusips match but company names do not match   
# - 5: tickers and company names match but 6-digit cusips do not match        
# - 6: tickers match but company names and 6-digit cusips do not match        

import wrds
import pandas as pd
import numpy as np
from fuzzywuzzy import fuzz

###################
# Connect to WRDS #
###################
conn=wrds.Connection()


    
###----------------------------------------------------------------------------
###                            Step 1: Link by CUSIP
###----------------------------------------------------------------------------

#########################
# 1.1 IBES: Get the list of IBES Tickers for US firms in IBES
#########################
ibes1 = conn.raw_sql("""
                      select ticker, cusip, cname, sdates from ibes.id
                      where usfirm=1 and cusip != ''
                      """)

### Duplicated ticker-cusip records,
### since sdates change whenever the name set changes
### Create first and last 'start dates' for a given cusip.
ibes1_date = ibes1.groupby(['ticker','cusip']).sdates.agg(['min', 'max'])\
                .reset_index().rename(columns={'min':'fdate', 'max':'ldate'})

# merge fdate ldate back to _ibes1 data
ibes2 = pd.merge(ibes1, ibes1_date,how='left', on =['ticker','cusip'])
ibes2 = ibes2.sort_values(by=['ticker','cusip','sdates'])

# keep only the most recent record, for later comparison of company name
# while also want to keep the effective date range of the cusip, so keep fdate
ibes2 = ibes2.loc[ibes2.sdates == ibes2.ldate].drop(['sdates'], axis=1)

#########################
# 1.2 CRSP: Get all permno-ncusip combinations
#########################
crsp1 = conn.raw_sql("""
                      select permno, ncusip, comnam, namedt, nameenddt
                      from crspq.stocknames
                      where ncusip != ''
                      """)
# effective period of each ncusip
crsp1_dtrange = crsp1.groupby(['permno','ncusip'])\
                .agg({'namedt':np.min,'nameenddt':np.max}).reset_index()
# replace namedt and nameenddt with the version from the dtrange
crsp1 = crsp1.drop(['namedt'],axis=1).rename(columns={'nameenddt':'enddt'})
crsp2 = pd.merge(crsp1, crsp1_dtrange, on =['permno','ncusip'], how='inner')
# keep only most recent company name
crsp2 = crsp2.loc[crsp2.enddt == crsp2.nameenddt].drop(['enddt'], axis=1)

#########################
# 1.3 Create CUSIP Link Table
#########################
# Link by cusip
link1_1 = pd.merge(ibes2, crsp2, how='inner', left_on='cusip', 
                   right_on='ncusip').sort_values(['ticker','permno','ldate'])
link1_1.groupby(['ticker','permno']).size().unique() #ticker-permno record is not unique

# for each link, ticker-permno, keep the most recent company name
link1_1_last = link1_1.groupby(['ticker','permno']).ldate.max().reset_index()
link1_2 = pd.merge(link1_1, link1_1_last, how='inner', on =['ticker', 'permno', 'ldate'])


### Calculate name matching ratio using FuzzyWuzzy

# Note: fuzz ratio = 100 -> match perfectly
#       fuzz ratio = 0   -> do not match at all

# Comment: token_set_ratio is more flexible in matching the strings:
# fuzz.token_set_ratio('AMAZON.COM INC',  'AMAZON COM INC')
# returns value of 100

# fuzz.ratio('AMAZON.COM INC',  'AMAZON COM INC')
# returns value of 93

link1_2['name_ratio'] = link1_2.apply(lambda x: fuzz.token_set_ratio(x.comnam, x.cname), axis=1)

# Note on parameters:
# The following parameters are chosen to mimic the SAS macro %iclink
# In %iclink, name_dist < 30 is assigned score = 0
# where name_dist=30 is roughly 90% percentile in total distribution
# and higher name_dist means more different names.
# In name_ratio, I mimic this by choosing 10% percentile as cutoff to assign
# score = 0

# 10% percentile of the company name distance
name_ratio_p10 = link1_2.name_ratio.quantile(0.10)

# Function to assign score for companies matched by:
# full cusip and passing name_ratio
# or meeting date range requirement

def score1(row):
    if (row['fdate']<=row['nameenddt']) & (row['ldate']>=row['namedt'])\
        & (row['name_ratio'] >= name_ratio_p10):
        score = 0
    elif (row['fdate']<=row['nameenddt']) & (row['ldate']>=row['namedt']):
        score = 1
    elif row['name_ratio'] >= name_ratio_p10:
        score = 2
    else:
        score = 3
    return score

# assign size portfolio
link1_2['score']= link1_2.apply(score1, axis=1)
link1_2 = link1_2[['ticker','permno','cname','comnam','name_ratio','score']]
link1_2.duplicated().sum() #good! no duplicated
link1_2 = link1_2.drop_duplicates() #seems they are not sure whether previous process can yield unique records, but want it to be anyway afterward


###----------------------------------------------------------------------------
###                            Step 2: Link by TICKER
###----------------------------------------------------------------------------


# Find links for the remaining unmatched cases using Exchange Ticker 

# Identify remaining unmatched IBES ticker
nomatch1 = pd.merge(ibes2[['ticker']], link1_2[['permno','ticker']], on='ticker', how='left')
nomatch1 = nomatch1.loc[nomatch1.permno.isnull()].drop(['permno'], axis=1).drop_duplicates()

# Add IBES identifying information

ibesid = conn.raw_sql(""" select ticker, cname, oftic, sdates, cusip from ibes.id """)
ibesid = ibesid[ibesid.oftic.notna()]

nomatch2 = pd.merge(nomatch1, ibesid, how='inner', on=['ticker'])

# Create first and last 'start dates' for Exchange Tickers
# Label date range variables and keep only most recent company name

nomatch2_date = nomatch2.groupby(['ticker', 'oftic']).sdates.agg(['min', 'max'])\
            .reset_index().rename(columns={'min':'fdate', 'max':'ldate'})

nomatch3 = pd.merge(nomatch2, nomatch2_date, how='left', on=['ticker','oftic'])
#keep the latest company name
nomatch3 = nomatch3[nomatch3.sdates == nomatch3.ldate]

# Get entire list of CRSP stocks with Exchange Ticker information
crsp_n1 = conn.raw_sql(""" select ticker, comnam, permno, ncusip, namedt, nameenddt
                            from crspq.stocknames """)

crsp_n1 = crsp_n1[crsp_n1.ticker.notna()].sort_values(by=['permno','ticker','namedt'])

# Arrange effective dates for link by Exchange Ticker
crsp_n1_dt = crsp_n1.groupby(['permno','ticker']).agg({'namedt':np.min,'nameenddt':np.max})

crsp_n1 = crsp_n1.drop(columns=['namedt']).rename(columns={'nameenddt':'nameenddt_ind'})
crsp_n2 = pd.merge(crsp_n1, crsp_n1_dt, how ='left', on = ['permno','ticker'])

crsp_n2 = crsp_n2.rename(columns={'ticker':'crsp_ticker'})
crsp_n2 = crsp_n2.loc[crsp_n2.nameenddt_ind == crsp_n2.nameenddt].drop(['nameenddt_ind'], axis=1)

### Merge remaining unmatched cases using Exchange Ticker 
### Note: Use ticker date ranges as exchange tickers are reused overtime
link2_1 = pd.merge(nomatch3, crsp_n2, how='inner', left_on=['oftic'], right_on=['crsp_ticker'])
link2_1 = link2_1.loc[(link2_1.ldate>=link2_1.namedt) & (link2_1.fdate<=link2_1.nameenddt)]


# Score using company name using 6-digit CUSIP and company name spelling distance
link2_1['name_ratio'] = link2_1.apply(lambda x: fuzz.token_set_ratio(x.comnam, x.cname), axis=1)

link2_1['cusip6'] = link2_1['cusip'].apply(lambda x: x[:6])
link2_1['ncusip6'] = link2_1.apply(lambda x: x.ncusip[:6], axis=1)

# Score using company name using 6-digit CUSIP and company name spelling distance

def score2(row):
    if (row['cusip6']==row['ncusip6']) & (row['name_ratio'] >= name_ratio_p10):
        score = 0
    elif (row['cusip6']==row['ncusip6']):
        score = 4
    elif row['name_ratio'] >= name_ratio_p10:
        score = 5
    else:
        score = 6
    return score

# assign size portfolio
link2_1['score']=link2_1.apply(score2, axis=1)

# Some companies may have more than one TICKER-PERMNO link
# so re-sort and keep the case (PERMNO & Company name from CRSP)
# that gives the lowest score for each IBES TICKER 

link2_2 = link2_1[['ticker','permno','cname','comnam', 'name_ratio', 'score']].sort_values(by=['ticker','score'])
link2_2_score = link2_2.groupby(['ticker']).score.min().reset_index()

link2_3 = pd.merge(link2_2, link2_2_score, how='inner', on=['ticker', 'score'])
link2_3 = link2_3[['ticker','permno','cname','comnam','score']].drop_duplicates()


#####################################
# Step 3: Finalize LInks and Scores #
#####################################

iclink = link1_2.append(link2_3)

# Storing iclink for other program usage
import pickle as pkl

with open('/home/amanela/Dropbox/KadanManela/InfoVal/data/earnings/iclink.pkl', 'wb') as f:
    pkl.dump(iclink, f)