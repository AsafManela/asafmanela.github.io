dateconv(x) = epochdays2date(x) + Year(1960)

# dta files are slightly smaller than sas fiels and make variables lowercase
function loadtaqms(;test=false)

    if test
        datafile = joinpath(testdatadir(), "infoval.csv")
        isfile(datafile) || @error "taq file is missing! $datafile"
        @time df = CSV.read(datafile, DataFrame)
    else
        datafile = joinpath(taqdir(), "infoval.sas7bdat")    
        isfile(datafile) || @error "taq file is missing! $datafile"
        @time df = load(datafile) |> DataFrame
    end

    @info "taq df size is $(size(df))"

    #lowercase key colnames
    rename!(df, :DATE=>:date, :SYM_ROOT=>:symbol)
    
    # convert dates
    df.date = dateconv.(df.date)
    df.yyyymm = [year(d)*100 + month(d) for d in df.date]

    # symroot is the ticker so primary key
    @info "disallow missing symbol"
    @time disallowmissing!(df, :symbol)

    @info "sorting by symbol and date"
    @time sort!(df, [:symbol, :date])

    # @info "adding lagged closing price"
    # @time lagdf = combine(groupby(df, :symbol), :date, :closeprice => lag => :lag1close)
    # @info "merging with lagdf"
    # @time df = innerjoin(df, lagdf, on=[:symbol, :date])

    lag!(df, :closeprice, 1, :symbol, :date)
    rename!(df, :lag1closeprice=>:lag1close)

    if test
        @info describe(df)
    end

    df
end

function loadccm(;test=false)

    if test
        datafile = joinpath(testdatadir(),"ccm.csv")
    else
        datafile = joinpath(wrdsdir(), "ccm_daily.csv")
    end

    isfile(datafile) || @error "ccm is missing! $datafile"

    df = CSV.read(datafile, DataFrame)
    @info "ccm df size is $(size(df))"

    df.szport = categorical(df.szport)
    df.bmport = categorical(df.bmport)

    if test
        @info describe(df)
    end

    # sort by ticker, date and tsymbol so that removing duplicates 
    # would keep A and not B shares
    @time sort!(df, [:ticker, :date, :tsymbol])
    @info "ccm sorted"

    ix = nonunique(df, [:ticker, :date])
    if sum(ix) > 0
        @warn "Dropping $(sum(ix)) duplicate rows from ccm.csv:"
        @warn df[ix, :]
        df = df[.! ix, :]
    end

    rename!(df, :ticker=>:symbol)
end

function loadearnings(;test=false)

    if test
        datafile = joinpath(testdatadir(), "earnings.csv")
    else
        datafile = joinpath(datadir(), "earnings", "earnings.csv")
    end

    isfile(datafile) || @error "earnings is missing! $datafile"

    @time df = CSV.read(datafile, DataFrame)
    @info "earnings df size is $(size(df))"

    df.permno = Int.(df.permno)
    rename!(df, :ead=>:date)
    @info "using Engelberg et al.(2018) earning announcement dates"

    if test
        @info describe(df)
    end

    @time df = sort!(df, [:permno, :date])
    
    ix = nonunique(df, [:permno, :date])
    if sum(ix) > 0
        @warn "Dropping $(sum(ix)) duplicate rows from earnings.csv:"
        @warn df[ix, :]
        df = df[.! ix, :]
    end

    select!(df, [:permno, :date, :sue1])

    df
end

const cpibaseyyyymm = 202012

function loadcpi(;test=false)

    if test
        datafile = joinpath(testdatadir(), "CPIAUCSL.csv")
    else
        datafile = joinpath(datadir(), "fred", "CPIAUCSL.csv")
    end

    isfile(datafile) || @error "cpi data is missing! $datafile"

    @time df = CSV.read(datafile, DataFrame)
    @info "cpi df size is $(size(df))"

    df.yyyymm = [year(d)*100 + month(d) for d in df.DATE]
    @info "Inflation adjustment using Consumer Price Index for All Urban Consumers: All Items in U.S. City Average (CPIAUCSL)"

    @info "CPI Index $cpibaseyyyymm = 1"
    basecpi = df[df.yyyymm .== cpibaseyyyymm, :CPIAUCSL][1]
    df.cpifactor = basecpi ./ df.CPIAUCSL

    if test
        @info describe(df)
    end

    @time df = sort!(df, :yyyymm)

    select!(df, [:yyyymm, :cpifactor, :DATE])

    df
end

"Add earnings announcement date event time variable"
function eadeventtime!(df, w=10)
    @assert issorted(df, [:permno; :date]) "Dataframe `df` must be sorted by permno and date first!"

    n = size(df,1)
    df.earntime = missings(Int, n)

    for i = 1:n
        if df[i, :ead]
            # earning announcement day found
            s = df[i, :permno]

            # iterate over window
            for j = -w:w
                ij = i + j
                # only replace if same permno and valid index
                if (1<=ij<=n) && (s == df[ij, :permno])
                    df[ij, :earntime] = j
                end
            end
        end
    end

    transform!(df, :earntime=>categorical, renamecols=false)
end

function loaddata(params::Params)
    @extract params : test rvbenchmark

    # taq = loadtaqsec(;test=test)
    taq = loadtaqms(;test=test)
    ccm = loadccm(;test=test)
    ern = loadearnings(;test=test)
    cpi = loadcpi(;test=test)

    @info "merging ccm with earnings data ..."
    @time df = leftjoin(ccm, ern, on=[:permno, :date])

    # we match CRSP :ticker to TAQ :sym_root after renaming both to :symbol
    # get very similar results when matching to CRSP :tsymbol (slightly smaller sample)
    @info "merging taq and ccm data ..."
    @time df = innerjoin(df, taq, on=[:symbol, :date])

    # indicator for earning announcement date
    df.ead = [!ismissing(x) for x in df.sue1]

    @info "merging with cpi data ..."
    @time df = innerjoin(df, cpi, on=:yyyymm)

    if !isempty(rvbenchmark) 
        @info "merging with market variance"
        mkt = loadtaqsymbol(;symbol=rvbenchmark, varprefix="mkt", df=taq)
        @time df = innerjoin(df, mkt[!, [:date, :mktrv, :mktrvi]], on=:date)
    end

    if test
        @info describe(df)
    end

    sort!(df, [:permno, :date])
end

"Extracts SPY only (or any other `symbol`) from taq data given as `df` or loads it itself"
function loadtaqsymbol(;symbol="SPY", varprefix=symbol, test=false, df=loadtaqms(;test=test))

    @info "keeping only $symbol observations"
    df = df[df.symbol .== symbol, :]

    cleanrv!(df)

    cols = [:date, :rv, :rvi, :rv0, :σ, :σi]

    select!(df, cols)

    rename!(df, [c=>string(varprefix,c) for c in cols[2:end]])
end

"""
Retains values over missing ones along the tsvar dimension as 
long as `idvars` stay constant.
"""
function retain!(df, idvars, tsvar, retainvars)
    @assert issorted(df, [idvars; tsvar]) "Dataframe `df` must be sorted by $([idvars; tsvar]) first!"

    # dims
    nvars = length(retainvars)

    # init storage for lagged ids and values
    lagids = missings(length(idvars))
    lagvalues = missings(nvars)

    for row = eachrow(df)
        ids = row[idvars]
        values = row[retainvars]
        if lagids == ids
            # same ids so check for missings
            for col = retainvars
                if ismissing(values[col]) && !ismissing(lagvalues[col])
                    # retain missing value
                    # @info "replacing row[$col] missing with $(lagvalues[col])"
                    values[col] = lagvalues[col]
                end
            end
        else
            # replace lagids
            lagids = ids
        end

        # in any case store as lagvalues
        lagvalues = values
    end

    df
end

"""
    winsor(x; prop=0.0, count=0)

Return a copy of `x` with either `count` or proportion `prop` of the lowest
elements of `x` replaced with the next-lowest, and an equal number of the
highest elements replaced with the previous-highest.  To compute the Winsorized
mean of `x` use `mean(winsor(x))`.

# Example
```julia
julia> winsor([5,2,3,4,1], prop=0.2)
5-element Array{Int64,1}:
 4
 2
 3
 4
 2
```
"""
function winsor(x::AbstractVector; prop::Real=0.0, count::Integer=0)
    winsor!(copy(x); prop=prop, count=count)
end

"""
    winsor!(x; prop=0.0, count=0)

A variant of [`winsor`](@ref) that modifies vector `x` in place.
"""
function winsor!(x::AbstractVector; prop::Real=0.0, count::Integer=0)
    n = length(x)
    n > 0 || throw(ArgumentError("x can not be empty."))

    if count == 0
        0 <= prop < 0.5 || throw(ArgumentError("prop must satisfy 0 ≤ prop < 0.5."))
        count = floor(Int, n * prop)
    else
        prop == 0 || throw(ArgumentError("prop and count can not both be > 0."))
        0 <= count < n/2 || throw(ArgumentError("count must satisfy 0 ≤ count < length(x)/2."))
    end

    ix = partialsortperm(x, 1:(count+1))
    x[ix[1:count]] .= x[ix[count+1]]

    ix = partialsortperm(x, (n-count):n)
    x[ix[2:end]] .= x[ix[1]]

    return x
end

"Ex-ante value of idiosyncratic information given fundamental's variance σv2, illiquidity λ, and inital price p"
infoval(σv2, λ, p) = missing
function infoval(σv2::T, λ::T, p::T) where T <: Number 
    if iszero(λ)
        missing
    else
        (σv2 / λ) * p
    end
end

"""
Calculates realized variance based on dataframe `df`

`rv` = annualized total (overnight+intraday) variance
`rv0`= annualized overnight variance
`rvi`= annualized intraday variance
"""
function cleanrv!(df)
    # rename annualized intraday variance
    rename!(df, :irv60sec=>:rvi)

    # annualized overnight realized return and variance
    df.retctoc = log.(df.closeprice ./ df.lag1close)
    df.ret0 = df.retctoc - (df.iret60sec * T)
    df.rv0 = (df.ret0.^2) / T
    df.retctoc ./= T
    df.ret0 ./= T

    # annualized total (overnight+intraday) variance
    df.rv = df.rv0 + df.rvi
    @info "rv is trade-based log return variance per 1 minutes"

    # annualized volatility
    df.σi = sqrt.(df.rvi)
    df.σ = sqrt.(df.rv)
    
    df
end

"Calculate infovals based on specific lambda variable and winsorize"
function clean(df::DataFrame, params::Params)
    @extract params : minprice infladj rvbenchmark

    ix = [!ismissing(x) && x>= minprice for x in df.lag1close]
    df = df[ix, :]
    @info "kept only $(sum(ix)) observations with at least $minprice nominal lagged stock price ($(100mean(ix))% of obs)"

    # set price impact variable
    rename!(df, λvar(params)=>:λ)

    # set realized variance properly
    cleanrv!(df)

    if infladj
        @info "Adjusting all prices for inflation (lag1close, wt)"
        df.lag1close .*= df.cpifactor
        df.wt .*= df.cpifactor
    end

    # p = closing price in $M
    p = df.lag1close / 10^6

    if !isempty(rvbenchmark)
        @info "Subtracting from each stock's rv the $rvbenchmark rv"
        df.rv -= df.mktrv
        df.rvi -= df.mktrvi

        @info "Note volatilities (σ,σi) are restricted to be nonnegative"
        df.σi = sqrt.(clamp.(df.rvi,0.0,typemax(Float64)))
        df.σ = sqrt.(clamp.(df.rv,0.0,typemax(Float64)))
    end

    # value of information
    df.V = broadcast(infoval, df.rv, df.λ, p)
    df.Vi = broadcast(infoval, df.rvi, df.λ, p)

    # price impact per million dollar = λ/p
    df.λp = df.λ ./ p

    musthavevars = [:permno, :date, :rv, :λ, :λp, :V, :Vi, :wt, :beme, :szport, :bmport]
    extravars = [:symbol, :ead, :σi, :σ, :lag1close, :yyyymm, :momret, :numest_exc, :disp1, :disp2]
    df = dropmissing!(df[!, vcat(musthavevars, extravars)], musthavevars)
    @info "kept only observations that have $musthavevars"

    df.rvw = winsor(df.rv, prop = 0.01)
    df.λpw = winsor(df.λp, prop = 0.01)
    df.Vw = winsor(df.V, prop = 0.01)
    df.Viw = winsor(df.Vi, prop = 0.01)
    # wt is last month's market cap
    df.lnwtw = winsor([log(x) for x in df.wt], prop = 0.01)
    # beme is last june book equity divided by last december market equity
    df.bemew = winsor(df.beme, prop = 0.01)
    # momret is the monthly return over months -2 to -12
    df.momretw = winsor(df.momret, prop = 0.01)
    df.σiw = winsor(df.σi, prop = 0.01)
    df.σw = winsor(df.σ, prop = 0.01)
    df.numest_excw = winsor(df.numest_exc, prop = 0.01)
    # replace ~ 1000 disp1=Inf obs with missing to ignore them entirely
    df.disp1w = winsor(replace(df.disp1, Inf=>missing), prop = 0.01)
    df.disp2w = winsor(df.disp2, prop = 0.01)
    @info "Variables with 'w' suffix are winsorized at 0.01 level"

    # add earning event time
    eadeventtime!(df,22)

    df
end

function loadclean(params::Params)
    @info "Loading clean infoval data for $params ..."

    @extract params : cachedata
    cf = cachefile("infovaldf", params)
    if cachedata && incache(cf)
        infovaldf = cache(cf)
        @info "clean infovaldf loaded from $cf"
    else
        @info "building clean infovaldf dataset"
        df = loaddata(params)
        infovaldf = clean(df, params)
        cache(cf, infovaldf)
        @info "clean infovaldf saved to $cf"
    end

    infovaldf
end

logmiss(x) = (x <= 0 ? missing : log(x))

"Cache file name"
function cachefile(name::String, params::Params) 
    @extract params : test
    
    joinpath(cachedir(), "$name$params.jld2")
end

"Save result to cache file"
cache(file::String, df) = save(file, "df", df; compress=true)

"Load result from cache file"
cache(file::String) = load(file, "df")

"Return true if cache file exists"
incache(file::String) = isfile(file)

incache(f::Function, name::String, params::Params) = incache(cachefile("$(f)_$(name)", params))
function cache(f::Function, name::String, params::Params, args...; kwargs...)

    cf = cachefile("$(f)_$(name)", params)
    res = nothing
    if params.cachedata && incache(cf)
        try
            res = cache(cf)
            @info "$f result loaded from $cf"
        catch e
            @error "failed to load $f result from $cf even though it appears to cached because!" exception=(e, catch_backtrace())
        end
    end

    if isnothing(res)
        @info "cache not found in $cf"
        @info "running $f"
        res = f(args...; kwargs...)
        cache(cf, res)
        @info "$f result saved to $cf"
    end
    res
end
