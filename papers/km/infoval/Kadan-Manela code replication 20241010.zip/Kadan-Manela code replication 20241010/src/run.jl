using InfoVal: analyze, robustness, Params, loadclean, logdir, jobid, storagedir

@info "InfoVal loaded with storagedir=$(storagedir())"

using Logging, IOLogging

if !isinteractive()
    outfile = joinpath(logdir(),"run.$(jobid()).out.log")
    logger = FileLogger(Dict(Logging.Info => outfile))
    global_logger(logger)
end

@info "run started"

if isinteractive()
    # hard-coded setting
    args = "minprice=0"
else
    # command-line setting
    args = ARGS[1]
end

if contains(args, "robustness")
    @info "robustness analysis"
    
    robustness()

    @info "robustness run done"
else
    params = eval(Meta.parse(string("Params(", args, ")")))

    @info "params = $params"

    # load data
    infovaldf = loadclean(params)

    # analyze 
    analyze(infovaldf, params)

    @info "run for $params done"
end