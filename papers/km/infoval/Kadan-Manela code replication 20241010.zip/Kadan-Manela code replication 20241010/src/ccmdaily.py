##########################################
# Fama French Factors
# Original: Qingyi (Freda) Song Drechsler
# April 2018
#
# Modified: Asaf Manela, Jiaen Li
# Jul 2021

# datadir is based on the environment variable STORAGE1 which should be set before running python
import os
projdir = '/home/amanela/Dropbox/KadanManela/InfoVal/'
datadir = projdir + 'data/wrds/'
earndir = projdir + 'data/earnings/'

# set sample date range, the earliest is in 1980s.
comp_begdate = '01/01/2000'
comp_enddate = '12/31/2021'

# set CRSP date range a bit wider to guarantee collecting all information
crsp_begdate = '01/01/2000'
crsp_enddate = '12/31/2021'

# IBES sample period: need to be wider than CRSP
ibes_begdate = '01/01/2000'
ibes_enddate = '12/31/2021'

import pandas as pd
import numpy as np
import datetime as dt
import wrds
# import psycopg2 
# import matplotlib.pyplot as plt
from dateutil.relativedelta import *
from pandas.tseries.offsets import *
# from scipy import stats

###################
# Connect to WRDS #
###################
conn=wrds.Connection()

###################
# Compustat Block #
###################
comp = conn.raw_sql(f"""
                    select gvkey, datadate, at, pstkl, txditc,
                    pstkrv, seq, pstk
                    from comp.funda
                    where indfmt='INDL' 
                    and datafmt='STD'
                    and popsrc='D'
                    and consol='C'
                    and datadate between '{comp_begdate}' and '{comp_enddate}'
                    """, date_cols=['datadate'])

comp['year']=comp['datadate'].dt.year

# create preferrerd stock
comp['ps']=np.where(comp['pstkrv'].isnull(), comp['pstkl'], comp['pstkrv'])
comp['ps']=np.where(comp['ps'].isnull(),comp['pstk'], comp['ps'])
comp['ps']=np.where(comp['ps'].isnull(),0,comp['ps'])

comp['txditc']=comp['txditc'].fillna(0)

# create book equity
comp['be']=comp['seq']+comp['txditc']-comp['ps']
comp['be']=np.where(comp['be']>0, comp['be'], np.nan)

# number of years in Compustat
comp=comp.sort_values(by=['gvkey','datadate'])
comp['count']=comp.groupby(['gvkey']).cumcount()

comp=comp[['gvkey','datadate','year','be','count']]

###########################
# CRSP Monthly Block      #
###########################
# sql similar to crspmerge macro
crsp_m = conn.raw_sql(f"""
                      select a.permno, a.permco, a.date, b.shrcd, b.exchcd,
                      a.ret, a.retx, a.shrout, a.prc, a.cfacpr
                      from crspq.msf as a
                      left join crspq.msenames as b
                      on a.permno=b.permno
                      and b.namedt<=a.date
                      and a.date<=b.nameendt
                      where a.date between '{crsp_begdate}' and '{crsp_enddate}'
                      and b.exchcd between 1 and 3
                      and b.shrcd between 10 and 11
                      """, date_cols=['date']) 

# change variable format to int
crsp_m[['permco','permno','shrcd','exchcd']]=crsp_m[['permco','permno','shrcd','exchcd']].astype(int)

# Line up date to be end of month
crsp_m['jdate']=crsp_m['date']+MonthEnd(0)

# add delisting return
dlret = conn.raw_sql("""
                     select permno, dlret, dlstdt 
                     from crspq.dsedelist
                     """, date_cols=['dlstdt'])

dlret.permno=dlret.permno.astype(int)
dlret['jdate']=dlret['dlstdt']+MonthEnd(0)

crsp = pd.merge(crsp_m, dlret, how='left',on=['permno','jdate'])
crsp['dlret']=crsp['dlret'].fillna(0)
crsp['ret']=crsp['ret'].fillna(0)

# retadj factors in the delisting returns
crsp['retadj']=(1+crsp['ret'])*(1+crsp['dlret'])-1

# average price for scaling the analysts' forecasts dispersion
crsp['prc_adj'] = abs(crsp['prc']/crsp['cfacpr'])
crsp = crsp.sort_values(by=['permno','date'])
crsp['lag_prc_adj'] = crsp.groupby(['permno'])['prc_adj'].shift(1)
crsp['lag_prc_adj'] = crsp['lag_prc_adj'].fillna(crsp['prc_adj'])
crsp['mean_prc'] = (crsp['prc_adj']+crsp['lag_prc_adj'])/2

# calculate market equity
crsp['me']=crsp['prc'].abs()*crsp['shrout'] 
crsp=crsp.drop(['dlret','dlstdt','prc','shrout'], axis=1)
crsp=crsp.sort_values(by=['jdate','permco','me'])

### Aggregate Market Cap ###
# sum of me across different permno belonging to same permco a given date
crsp_summe = crsp.groupby(['jdate','permco'])['me'].sum().reset_index()

# largest mktcap within a permco/date
crsp_maxme = crsp.groupby(['jdate','permco'])['me'].max().reset_index()

# join by jdate/maxme to find the permno
crsp1=pd.merge(crsp, crsp_maxme, how='inner', on=['jdate','permco','me'])

# drop me column and replace with the sum me
crsp1=crsp1.drop(['me'], axis=1)

# join with sum of me to get the correct market cap info
crsp2=pd.merge(crsp1, crsp_summe, how='inner', on=['jdate','permco'])

# sort by permno and date and also drop duplicates
crsp2=crsp2.sort_values(by=['permno','jdate']).drop_duplicates()

# keep December market cap
crsp2['year']=crsp2['jdate'].dt.year
crsp2['month']=crsp2['jdate'].dt.month
decme=crsp2[crsp2['month']==12]
decme=decme[['permno','date','jdate','me','year']].rename(columns={'me':'dec_me'})

### July to June dates
crsp2['ffdate']=crsp2['jdate']+MonthEnd(-6)
crsp2['ffyear']=crsp2['ffdate'].dt.year
crsp2['ffmonth']=crsp2['ffdate'].dt.month
crsp2['1+retx']=1+crsp2['retx']
crsp2=crsp2.sort_values(by=['permno','date'])

# cumret by stock
crsp2['cumretx']=crsp2.groupby(['permno','ffyear'])['1+retx'].cumprod()

# lag cumret
crsp2['lcumretx']=crsp2.groupby(['permno'])['cumretx'].shift(1)

# lag market cap
crsp2['lme']=crsp2.groupby(['permno'])['me'].shift(1)

# if first permno then use me/(1+retx) to replace the missing value
crsp2['count']=crsp2.groupby(['permno']).cumcount()
crsp2['lme']=np.where(crsp2['count']==0, crsp2['me']/crsp2['1+retx'], crsp2['lme'])

# lag 2-12 month ret
l2to12 = ['l' + str(l) + 'logret' for l in range(2,13)]
for l in range(2,13):
    crsp2['l' + str(l) + 'logret']=np.log(1+crsp2.groupby(['permno'])['ret'].shift(l))
crsp2['momret'] = np.exp(crsp2.loc[:, l2to12].sum(axis=1, min_count=1)) - 1
# crsp2[['permno', 'ticker', 'ret', 'l2logret', 'l12logret','momret']]
# crsp2[['l' + str(l) + 'logret' for l in range(2,13)]]
# crsp2.loc[crsp2['ticker'] == 'MSFT'][['permno', 'ticker', 'ret', 'l2logret', 'l12logret','momret']]
crsp2=crsp2.drop(columns=l2to12)

# baseline me
mebase=crsp2[crsp2['ffmonth']==1][['permno','ffyear', 'lme']].rename(columns={'lme':'mebase'})

# merge result back together
crsp3=pd.merge(crsp2, mebase, how='left', on=['permno','ffyear'])
crsp3['wt']=np.where(crsp3['ffmonth']==1, crsp3['lme'], crsp3['mebase']*crsp3['lcumretx'])

decme['year']=decme['year']+1
decme=decme[['permno','year','dec_me']]

# Info as of June
crsp3_jun = crsp3[crsp3['month']==6]

crsp_jun = pd.merge(crsp3_jun, decme, how='inner', on=['permno','year'])
crsp_jun=crsp_jun[['permno','date', 'year', 'month', 'jdate', 'shrcd','exchcd','retadj','me','wt','cumretx','mebase','lme','dec_me']]
crsp_jun=crsp_jun.sort_values(by=['permno','jdate']).drop_duplicates()

#%%######################
# IBES BLOCK          #
#######################
# Ref: WRDS, measuring investors' opinion divergence guide

# Query ibes variables:
# exclude erroneous observations for which forecast Announcement Date (ANNDATS)
# precedes the Review Date (REVDATS)
ibes_detail = conn.raw_sql(f"""
                         select ticker, fpedats, anndats, actdats, revdats, fpi,
                         analys, measure, value, anndats_act, estimator
                         from ibes.det_epsus 
                         where anndats_act > revdats
                         and fpedats > anndats
                         and analys != 0
                         and fpedats between '{ibes_begdate}' and '{ibes_enddate}'
                     """, 
                     date_cols = ['fpedats', 'anndats', 'actdats', 'revdats'])
                                      

ibes_detail['year'] = pd.DatetimeIndex(ibes_detail['anndats']).year
ibes_detail['month'] = pd.DatetimeIndex(ibes_detail['anndats']).month

ibes_detail = ibes_detail.sort_values(['ticker','fpedats','analys','year','month','anndats','revdats'])

# keep only the latest forecast record by an analyst in a given year-month
ibes_detail1 = ibes_detail.groupby(['ticker','fpedats','analys','year','month']).last().reset_index()

# Extract relevant stopped estimates
stopped = conn.raw_sql(f"""
                           select ticker, fpedats, estimator, astpdats
                           from ibes.stop_epsus
                           where pdicity='A'
                           and fpedats between '{ibes_begdate}' and '{ibes_enddate}'
                       """,
                       date_cols = ['fpedats', 'astpdats'])

stopped = stopped.dropna(subset=['astpdats'])

# groupby [ticker, fpedats, estimator], only keep astpdats = max(astpdats)
stopped = stopped.sort_values(['ticker','fpedats','estimator','astpdats'])
stopped = stopped.groupby(['ticker','fpedats','estimator']).last().reset_index()


# Extract relevant excluded estimates
excluded = conn.raw_sql(f""" 
                         select ticker, fpedats, actdats, estimator, analys, excdats, excends, fpi
                         from ibes.exc_epsus 
                         where fpedats between '{ibes_begdate}' and '{ibes_enddate}'
                         and fpi = '1'
                         """,
                         date_cols = ['fpedats', 'actdats', 'excdats'])
excluded = excluded.dropna(subset=['excdats'])

excluded = excluded.sort_values(['ticker', 'fpedats', 'actdats', 'estimator','analys','excdats'])
excluded = excluded.groupby(['ticker', 'fpedats', 'actdats', 'estimator','analys']).first().reset_index()


# Merge Detailed History Estimates with Stopped and Excluded files
ibes_detail1 = pd.merge(ibes_detail1, stopped, on=['ticker','estimator','fpedats'], how='left')
ibes_detail1 = pd.merge(ibes_detail1, excluded, on=['ticker', 'fpedats', 'actdats', 'estimator','analys','fpi'],how='left')


ibes_detail1 = ibes_detail1.drop(columns=['measure','actdats', 'year', 'month'])

ibes_detail1 = ibes_detail1.drop_duplicates()


# Remove forecasts that were stopped 
#  if (anndats>=astpdats) and nmiss(anndats,astpdats)=0 then delete
cond = (ibes_detail1['anndats']>=ibes_detail1['astpdats']) & (ibes_detail1['anndats'].notna()) & (ibes_detail1['astpdats'].notna())
ibes_detail1 = ibes_detail1[~cond]


# Get number of analysts (including excluded analysts) for each [ticker,year]
num_analyst = ibes_detail1[['ticker','fpedats','analys','estimator','anndats']].copy()
num_analyst['year'] = num_analyst['fpedats'].dt.year
num_analyst = (num_analyst.groupby(['ticker','year'])['analys'].nunique()
            .reset_index().rename(columns={'analys':'numest_exc'}))


# Remove forecasts that were excluded

ibes_detail1 = ibes_detail1[ibes_detail1['fpi']=='1']

# if (nmiss(excdats,excends)=0 and excdats<=anndats<=excends) then delete
cond1 = (ibes_detail1['excdats'].notna()) & (ibes_detail1['excends'].notna()) 
cond2 = (ibes_detail1['excdats']<=ibes_detail1['anndats']) & (ibes_detail1['anndats']<=ibes_detail1['excends'])
cond = (cond1 & cond2)
ibes_detail1 = ibes_detail1[~cond]

# if (not missing(excdats) and anndats>=excdats) then delete
cond = (ibes_detail1['excdats'].notna()) & (ibes_detail1['anndats'] >= ibes_detail1['excdats'])
ibes_detail1 = ibes_detail1[~cond]


ibes_detail1 = ibes_detail1.drop(columns=['astpdats','excdats','excends','fpi'])


# To alleviate, albeit not eliminate, the issue of forecast staleness.
# The Estimate will be carried forward to either the next estimate issue date,    
# Anndats(t+1), or Anndats(t)+105, or EAD, whichever comes sooner                
# Ensure forecast dispersion measure does not include stale forecasts   

# Sorting anndats and revdats in descending order is intentional to define leads
ibes_detail1 = ibes_detail1.sort_values(by=['ticker','fpedats','analys', 'anndats','revdats'],
                          ascending = [True,True,True,False,False])
# force unique obs
ibes_detail1 = ibes_detail1.drop_duplicates(subset=['ticker','fpedats','analys','anndats','revdats'])


ibes_detail1['anndats+105'] = ibes_detail1['anndats'] + dt.timedelta(days=105)
ibes_detail1['l_anndats'] = ibes_detail1['anndats'].shift(1)
ibes_detail1['leadanndats'] = ibes_detail1[['l_anndats','anndats+105']].min(axis=1)
ibes_detail1['count'] = ibes_detail1.groupby(['ticker','analys'])['fpedats'].cumcount()
ibes_detail1['leadanndats'] = np.where(ibes_detail1['count']==0, 
                                ibes_detail1[['anndats+105','anndats_act']].min(axis=1),
                                ibes_detail1['leadanndats'])

ibes_detail1['leadanndats_me'] = ibes_detail1['leadanndats']+MonthEnd(0)
ibes_detail1['anndats_me'] = ibes_detail1['anndats']+MonthEnd(0)



# Populate Detailed Forecasts into monthly frequency
a = ibes_detail1.groupby('ticker')['anndats'].min().reset_index().rename(columns={'anndats':'minfdate'})            
b = ibes_detail1.groupby('ticker')['leadanndats'].max().reset_index().rename(columns={'leadanndats':'maxfdate'})
a = pd.merge(a,b,on='ticker')
a['maxfdate'] = a['maxfdate']+MonthEnd(0)
a['minfdate'] = a['minfdate']-MonthBegin(1)

date = conn.raw_sql(f"""
                    select date from crsp.msi
                    where date between '{ibes_begdate}' and '{ibes_enddate}'
                    """
                    , date_cols=['date'])
date = date.drop_duplicates() 
date['date'] = date['date']+MonthEnd(0)
date = date.T.apply(lambda x: x.repeat(len(a)))
date.reset_index(drop=True,inplace=True)

base = pd.concat([a, date],axis=1)
base = (base.set_index(['ticker','minfdate','maxfdate']).stack().reset_index()
            .rename(columns={0:'date'}).drop(columns='level_3'))
cond = (base['minfdate']<=base['date']) & (base['maxfdate']>=base['date'])
base = base[cond]
base = base.sort_values(by=['ticker','date'])


# Carrying the forecasts forward until the next appropriate date (leadanndats) 

# add date
dispersion = pd.merge(base, ibes_detail1, on='ticker', how='left')

dispersion1=dispersion[dispersion['anndats_me']<dispersion['leadanndats_me']]
cond = (dispersion1['anndats']<=dispersion1['date']) & (dispersion1['date']<dispersion1['leadanndats'])
dispersion1 = dispersion1[cond]
dispersion2 = dispersion[dispersion['anndats_me'] == dispersion['leadanndats_me']]
cond = (dispersion2['anndats']<=dispersion2['date']) & (dispersion2['date']<=dispersion2['leadanndats'])
dispersion2 = dispersion2[cond]

dispersion = dispersion1.append(dispersion2)

dispersion = dispersion.drop_duplicates()

# For a given (Ticker,date (monthly),Analyst, Forecast) combination, keep only those 
# records with the closest Fiscal Period End.
dispersion = dispersion.sort_values(by=['ticker','date','analys','fpedats','anndats'])
dispersion3 = dispersion.groupby(['ticker','date','analys']).first().reset_index()


# add permno
# iclink.pkl is the output from the python program iclink.py
# it contains the linking between crsp and ibes
iclink = pd.read_pickle(earndir + "iclink.pkl")
# only keep high quality links (score = 0 or 1) between crsp and ibes
iclink_hq = iclink[iclink.score <=1]
iclink_hq = iclink_hq.sort_values(['ticker','permno','name_ratio'])
iclink_hq = iclink_hq.groupby(['ticker','permno']).last().reset_index()
iclink_hq = iclink_hq[['ticker','permno']]

dispersion3 = pd.merge(dispersion3, iclink_hq, on=['ticker'])

# Calculate two versions of analyst forecast dispersion: one scaled by absolute 
# mean forecast value (DISP1), the other scaled by mean monthly price (DISP2) 
dispersion4 = pd.merge(dispersion3, crsp2[['permno','date','mean_prc']].dropna(), on=['permno','date'])
analyst_stat = dispersion4.groupby(['ticker','date','mean_prc','permno'])['value'].agg(['std','mean']).reset_index()
analyst_stat['disp1'] = analyst_stat['std']/analyst_stat['mean']
analyst_stat['disp2'] = analyst_stat['std']/analyst_stat['mean_prc']
analyst_stat['year'] = analyst_stat['date'].dt.year
analyst_stat = pd.merge(analyst_stat, num_analyst, on=['ticker','year'])
analyst_stat = analyst_stat[['ticker', 'date', 'permno', 'disp1', 'disp2', 'numest_exc']]
analyst_stat = analyst_stat.drop_duplicates(['permno','date']).rename(columns={'date':'jdate'})


#%%######################
# CCM Block           #
#######################
ccm=conn.raw_sql("""
                  select gvkey, lpermno as permno, linktype, linkprim, 
                  linkdt, linkenddt
                  from crspq.ccmxpf_lnkhist
                  where substr(linktype,1,1)='L'
                  and (linkprim ='C' or linkprim='P')
                  """, date_cols=['linkdt', 'linkenddt'])

# if linkenddt is missing then set to today date
ccm['linkenddt']=ccm['linkenddt'].fillna(pd.to_datetime('today'))

ccm1=pd.merge(comp[['gvkey','datadate','be', 'count']],ccm,how='left',on=['gvkey'])
ccm1['yearend']=ccm1['datadate']+YearEnd(0)
ccm1['jdate']=ccm1['yearend']+MonthEnd(6)

# set link date bounds
ccm2=ccm1[(ccm1['jdate']>=ccm1['linkdt'])&(ccm1['jdate']<=ccm1['linkenddt'])]
ccm2=ccm2[['gvkey','permno','datadate','yearend', 'jdate','be', 'count']]

# link comp and crsp
ccm_jun=pd.merge(crsp_jun, ccm2, how='inner', on=['permno', 'jdate'])
ccm_jun['beme']=ccm_jun['be']*1000/ccm_jun['dec_me']

# drop duplicate rows by keeping most recent observation
ccm_jun = ccm_jun.drop_duplicates(subset=['permno', 'jdate'], keep='last').copy()

# select NYSE stocks for bucket breakdown
# exchcd = 1 and positive beme and positive me and shrcd in (10,11) and at least 2 years in comp
nyse=ccm_jun[(ccm_jun['exchcd']==1) & (ccm_jun['beme']>0) & (ccm_jun['me']>0) & 
             (ccm_jun['count']>=1) & ((ccm_jun['shrcd']==10) | (ccm_jun['shrcd']==11))]

# size breakdown
nyse_sz=nyse.groupby(['jdate'])['me'].median().to_frame().reset_index().rename(columns={'me':'sizemedn'})

# beme breakdown
nyse_bm=nyse.groupby(['jdate'])['beme'].describe(percentiles=[0.3, 0.7]).reset_index()
nyse_bm=nyse_bm[['jdate','30%','70%']].rename(columns={'30%':'bm30', '70%':'bm70'})

nyse_breaks = pd.merge(nyse_sz, nyse_bm, how='inner', on=['jdate'])

# join back size and beme breakdown
ccm1_jun = pd.merge(ccm_jun, nyse_breaks, how='left', on=['jdate'])


# function to assign sz and bm bucket
def sz_bucket(row):
    if row['me']==np.nan:
        value=''
    elif row['me']<=row['sizemedn']:
        value='S'
    else:
        value='B'
    return value

def bm_bucket(row):
    if 0<=row['beme']<=row['bm30']:
        value = 'L'
    elif row['beme']<=row['bm70']:
        value='M'
    elif row['beme']>row['bm70']:
        value='H'
    else:
        value=''
    return value

# assign size portfolio
ccm1_jun['szport']=np.where((ccm1_jun['beme']>0)&(ccm1_jun['me']>0)&(ccm1_jun['count']>=1), ccm1_jun.apply(sz_bucket, axis=1), '')

# assign book-to-market portfolio
ccm1_jun['bmport']=np.where((ccm1_jun['beme']>0)&(ccm1_jun['me']>0)&(ccm1_jun['count']>=1), ccm1_jun.apply(bm_bucket, axis=1), '')

# create positivebmeme and nonmissport variable
ccm1_jun['posbm']=np.where((ccm1_jun['beme']>0)&(ccm1_jun['me']>0)&(ccm1_jun['count']>=1), 1, 0)
ccm1_jun['nonmissport']=np.where((ccm1_jun['bmport']!=''), 1, 0)

# store portfolio assignment as of June
june=ccm1_jun[['permno','date', 'jdate', 'bmport','szport','posbm','nonmissport','beme']]
june.loc[:, ('ffyear')]=june['jdate'].dt.year

# merge back with monthly records
crsp3 = crsp3[['date','permno','shrcd','exchcd','retadj','me','wt','cumretx','ffyear','jdate','year','month','momret']]
ccm3=pd.merge(crsp3, 
        june[['permno','ffyear','szport','bmport','posbm','nonmissport','beme']], how='left', on=['permno','ffyear'])

# keeping only records that meet the criteria
ccm4=ccm3[(ccm3['wt']>0)& (ccm3['posbm']==1) & (ccm3['nonmissport']==1) & 
          ((ccm3['shrcd']==10) | (ccm3['shrcd']==11))]

###########################
# CRSP Daily Block      #
# NOTE: this should be using crspq.dsf, but its having techinical difficiulties today
###########################
crsp_d = conn.raw_sql(f"""
                      select a.permno, a.permco, a.date, 
                      b.shrcd, b.exchcd, b.ticker, b.tsymbol,
                      a.ret, a.retx, a.shrout, a.prc
                      from crsp.dsf as a
                      left join crspq.dsenames as b
                      on a.permno=b.permno
                      and b.namedt<=a.date
                      and a.date<=b.nameendt
                      where a.date between '{crsp_begdate}' and '{crsp_enddate}'
                      and b.exchcd between 1 and 3
                      and b.shrcd between 10 and 11
                      """, date_cols=['date']) 

# conn.describe_table(library='crspq', table='msf')
conn.describe_table(library='crspq', table='dsf')
# conn.describe_table(library='crsp', table='dsf')
# conn.describe_table(library='crsp', table='dsenames')
# conn.describe_table(library='crspq', table='dsenames')
# crsp_d = conn.raw_sql(f"""
#                       select a.permno, a.permco, a.date, 
#                       a.ret, a.retx, a.shrout, a.prc
#                       from crspq.dsf as a
#                       where a.date between '{crsp_begdate}' and '{crsp_enddate}'
#                       """, date_cols=['date']) 

# change variable format to int
crsp_d[['permco','permno','shrcd','exchcd']]=crsp_d[['permco','permno','shrcd','exchcd']].astype(int)

# # Line up date to be end of month
# crsp_d['jdate']=crsp_d['date']#+MonthEnd(0)

# add delisting return
dlret = conn.raw_sql("""
                     select permno, dlret, dlstdt 
                     from crspq.dsedelist
                     """, date_cols=['dlstdt'])

dlret.permno=dlret.permno.astype(int)
dlret['date']=dlret['dlstdt'] #+MonthEnd(0)

crspd = pd.merge(crsp_d, dlret, how='left',on=['permno','date'])
crspd['dlret']=crspd['dlret'].fillna(0)
crspd['ret']=crspd['ret'].fillna(0)
crspd['retadj']=(1+crspd['ret'])*(1+crspd['dlret'])-1
crspd['me']=crspd['prc'].abs()*crspd['shrout'] # calculate market equity
crspd=crspd.drop(['dlret','dlstdt','prc','shrout'], axis=1)
crspd=crspd.sort_values(by=['date','permco','me'])

### Aggregate Market Cap ###
# sum of me across different permno belonging to same permco a given date
crspd_summe = crspd.groupby(['date','permco'])['me'].sum().reset_index()
# largest mktcap within a permco/date
crspd_maxme = crspd.groupby(['date','permco'])['me'].max().reset_index()
# join by date/maxme to find the permno
crspd1=pd.merge(crspd, crspd_maxme, how='inner', on=['date','permco','me'])
# drop me column and replace with the sum me
crspd1=crspd1.drop(['me'], axis=1)
# join with sum of me to get the correct market cap info
crspd2=pd.merge(crspd1, crspd_summe, how='inner', on=['date','permco'])
# sort by permno and date and also drop duplicates
crspd2=crspd2.sort_values(by=['permno','date']).drop_duplicates()

# keep last day of December market cap
crspd2['year']=crspd2['date'].dt.year
crspd2['month']=crspd2['date'].dt.month

ccm4d = pd.merge(crspd2, ccm4[['permno','year','month','szport','bmport','beme','wt','momret']], how='left', on=['permno','year','month'])

############################
# Form Fama French Factors #
############################

# function to calculate value weighted return
def wavg(group, avg_name, weight_name):
    d = group[avg_name]
    w = group[weight_name]
    try:
        return (d * w).sum() / w.sum()
    except ZeroDivisionError:
        return np.nan

# value-weigthed return
vwret=ccm4d.groupby(['date','szport','bmport']).apply(wavg, 'retadj','wt').to_frame().reset_index().rename(columns={0: 'vwret'})
vwret['sbport']=vwret['szport']+vwret['bmport']

# firm count
vwret_n=ccm4d.groupby(['date','szport','bmport'])['retadj'].count().reset_index().rename(columns={'retadj':'n_firms'})
vwret_n['sbport']=vwret_n['szport']+vwret_n['bmport']

# tranpose
ff_factors=vwret.pivot(index='date', columns='sbport', values='vwret').reset_index()
ff_nfirms=vwret_n.pivot(index='date', columns='sbport', values='n_firms').reset_index()

# create SMB and HML factors
ff_factors['WH']=(ff_factors['BH']+ff_factors['SH'])/2
ff_factors['WL']=(ff_factors['BL']+ff_factors['SL'])/2
ff_factors['WHML'] = ff_factors['WH']-ff_factors['WL']

ff_factors['WB']=(ff_factors['BL']+ff_factors['BM']+ff_factors['BH'])/3
ff_factors['WS']=(ff_factors['SL']+ff_factors['SM']+ff_factors['SH'])/3
ff_factors['WSMB'] = ff_factors['WS']-ff_factors['WB']
# ff_factors=ff_factors.rename(columns={'jdate':'date'})

# n firm count
ff_nfirms['H']=ff_nfirms['SH']+ff_nfirms['BH']
ff_nfirms['L']=ff_nfirms['SL']+ff_nfirms['BL']
ff_nfirms['HML']=ff_nfirms['H']+ff_nfirms['L']

ff_nfirms['B']=ff_nfirms['BL']+ff_nfirms['BM']+ff_nfirms['BH']
ff_nfirms['S']=ff_nfirms['SL']+ff_nfirms['SM']+ff_nfirms['SH']
ff_nfirms['SMB']=ff_nfirms['B']+ff_nfirms['S']
ff_nfirms['TOTAL']=ff_nfirms['SMB']
# ff_nfirms=ff_nfirms.rename(columns={'jdate':'date'})

##############################################
# Export to csv files
##############################################
ccm5=ccm4d[['date', 'permno', 'ticker', 'tsymbol', 'retadj', 'me', 'wt', 'szport', 'bmport', 'beme', 'momret']].rename(columns={'retadj':'ret'})
ccm5=ccm5.sort_values(by=['permno','date']).drop_duplicates()

ccm5['jdate'] = ccm5['date']+MonthEnd(0)
analyst_stat = analyst_stat.rename(columns={'ticker':'ibes_ticker'})
ccm5 = pd.merge(ccm5, analyst_stat, on = ['permno','jdate'], how='left')


# ccm5.groupby(['jdate'])['permno'].nunique().plot()
# analyst_stat.groupby(['jdate'])['permno'].count().plot()

ccm5.to_csv(datadir + 'ccm_daily.csv',index=False)

ccm5test=ccm5.loc[(ccm5['date'].dt.year == 2014) & (ccm5['date'].dt.month >= 11)]
ccm5test.to_csv(datadir + 'ccmtest2014_daily.csv',index=False)

ff_factors.to_csv(datadir + 'ff_factors_daily.csv',index=False)
ff_nfirms.to_csv(datadir + 'ff_nfirms_daily.csv',index=False)
