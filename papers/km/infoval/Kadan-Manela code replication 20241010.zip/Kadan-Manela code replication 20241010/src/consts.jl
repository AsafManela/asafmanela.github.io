testmode = false
testtempdir = ""

function settestmode(m)
    global testmode = m
    if m
        global testtempdir = mktempdir()
        mkpath(logdir())
        mkpath(figdir())
        mkpath(tbldir())
        @info "test mode set. files will be written to $testtempdir"
    else
        @info "test mode off. files will be written to $(storagedir())"
    end
end

function maybetempdir()
    global testmode, testtempdir
    if testmode
        testtempdir
    else
        storagedir()
    end
end

function storagedir()
    if haskey(ENV, "LSB_JOBID")
        # running on RIS compute's LSB
        joinpath(ENV["STORAGE1"], "ManelaLab", "InfoVal")
    else
        # running on local machine
        joinpath(homedir(), "Dropbox", "KadanManela", "InfoVal")
    end
end

# directories that cannot be temp
datadir() = joinpath(storagedir(), "data")
wrdsdir() = joinpath(datadir(), "wrds")
taqdir() = joinpath(datadir(), "taq")

# directories that can be temp
cachedir() = joinpath(maybetempdir(), "cache")
logdir() = joinpath(maybetempdir(), "log")
latexdir() = joinpath(maybetempdir(), "latex")
figdir() = joinpath(latexdir(), "figures")
tbldir() = joinpath(latexdir(), "tables")

# test data
testdatadir() = joinpath(@__DIR__, "..", "test", "data")

# make sure directories exist
mkpath(logdir())
mkpath(figdir())
mkpath(tbldir())
mkpath(cachedir())
mkpath(testdatadir())

function jobid()
    if haskey(ENV, "LSB_JOBID")
    # running on ris compute
        string(ENV["LSB_JOBID"], ".", gethostname())
    else
    # running on my server
        gethostname()
    end
end

# annualizing constants
const opentime = Time("09:30:00")
const closetime = Time("16:00:00")
const N = minsperday = Minute(closetime - opentime) / Minute(1)

const daysperyear = 252
const T = 1/daysperyear
const Δ = T/N
