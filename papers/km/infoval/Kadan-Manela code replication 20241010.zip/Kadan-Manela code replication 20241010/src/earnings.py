# -*- coding: utf-8 -*-
"""
Output: earnings.cvs
    permno, ticker, reporting date, SUE
    
Created: 05/05/2020
"""

import pandas as pd
import numpy as np
import wrds
# import matplotlib.pyplot as plt
import pickle as pkl
from dateutil.relativedelta import *
import datetime as dt

#**********************************************
# First-time connection
# Set up a pgpass file to connect to WRDS
# Can delete after successfully seting up
# db = wrds.Connection(wrds_username='user_name') #replace user_name with wrds acct
# db.create_pgpass_file()

###TEST###
# db.close()
# db=wrds.Connection(wrds_username='user_name') #replace user_name with wrds acct

#**********************************************


###############################################################################
###############################################################################

# Connect to WRDS
conn=wrds.Connection() #replace user_name with wrds acct

projdir = '/home/amanela/Dropbox/KadanManela/InfoVal/'
datadir = projdir + 'data/earnings/'

# Python is not customized for handling large dataset in memory
# efficiently as SAS is. Break up the sample period into batches and
# then piecing the outputs together.

# set sample date range, the earliest is in 1980s.
begdate = '01/01/2003'
enddate = '12/31/2021'

# set CRSP date range a bit wider to guarantee collecting all information
crsp_begdate = '01/01/2003'
crsp_enddate = '12/31/2021'


###########################
#     STEP 0: LINKAGE     #
###########################

# iclink.pkl is the output from the python program iclink.py
# it contains the linking between crsp and ibes
with open(datadir + 'iclink.pkl', 'rb') as f:
    iclink = pkl.load(f)
# only keep high quality links (score = 0 or 1) between crsp and ibes
iclink_hq = iclink[iclink.score <=1]

#-------------------------------------------
# NOTE:
# CRSP & Compustat: ccm
# CRSP & IBES: iclink
# Compustat & IBES:
#    primarily linked through permno from CRSP (ccm+iclink),
#    secondarily linked by IBTIC in Compustat Security file.
#-------------------------------------------
# linkage between crsp and compustat
ccm = conn.raw_sql("""
                   select gvkey, lpermco as permco, lpermno as permno,
                   linkdt, linkenddt
                   from crspq.ccmxpf_linktable
                   where usedflag=1 and linkprim in ('P', 'C')""")
ccm[['permco', 'permno']] = ccm[['permco', 'permno']].astype(int)
#effective dates of the gvkey-permno linkage
ccm['linkdt'] = pd.to_datetime(ccm['linkdt'])
ccm['linkenddt'] = pd.to_datetime(ccm['linkenddt'])
ccm['linkenddt'] = ccm['linkenddt'].fillna(pd.to_datetime('today')) #fill missing enddt with today

# secondary linkage between compustat and ibes
sec = conn.raw_sql("select ibtic, gvkey from comp.security")

# primarily link Compusta & IBES through permno
linkage = pd.merge(ccm, iclink_hq, on=['permno'], how='left')
# secondary link: fill missing ibes ticker with ibtic
linkage = pd.merge(linkage, sec[sec.ibtic.notna()], on=['gvkey'], how='left')
linkage['ticker'].fillna(linkage['ibtic'], inplace=True)

# keep relevant columns and drop duplicates if there is any
linkage = linkage[['gvkey', 'permco', 'permno', 'linkdt', 'linkenddt','ticker']].drop_duplicates()

# effective period of each ticker-permno pair, from ccm's linkdt and linkenddt
# linkage_dt effectively gives the unique tikcer-permno-gvkey linkage.
linkage_dt = linkage.groupby(['ticker','permno','permco']).agg({'linkdt':np.min,
                            'linkenddt':np.max}).reset_index()
# NOTE:
#    Adding 'permco' or not doesn't affect linkage_dt, keep 'permco' for sanity check.
#    All merges are done based on permno

    
    
#########################################
#    Step 1. Analysts' Forecasts        #
#########################################
# Query estimates from IBES Unadjusted file
# Keep the latest estimate of each analyst for each firm-fpe
# usfirm=1 is NOT imposed, but it's true. i.e., Only US firms are included. 

# individual estimates
# where "fpi in (6,7)" selects quarterly forecast for the current and the next fiscal quarter
ibes_est = conn.raw_sql(f"""
                        select ticker, estimator, analys, fpi, value,
                        fpedats, revdats, revtims, anndats, anntims
                        from ibes.detu_epsus
                        where fpedats between '{begdate}' and '{enddate}'
                        and (fpi='6' or fpi='7')
                        """, date_cols = ['revdats', 'anndats', 'fpedats'])

# merge with linkage_dt so that the anndats are within the effective period of the linkage
ibes_est1 = pd.merge(ibes_est, linkage_dt, how='left', on=['ticker'])
ibes_est1 = ibes_est1[(ibes_est1['linkdt']<=ibes_est1['anndats']) &
                        (ibes_est1['anndats'] <= ibes_est1['linkenddt'])]

# keep the latest observation for a given analyst.
ibes_est2 = (ibes_est1.sort_values(by=['ticker','fpedats','estimator','analys',
                             'anndats','anntims', 'revdats', 'revtims']) # there can be multiple revdats for one anndats
            .drop(columns=['linkdt', 'linkenddt', 'fpi']))
lastest = (ibes_est2.groupby(['ticker','fpedats','estimator','analys'])
              .apply(lambda x: x.index[-1]).to_frame().reset_index())
lastest = lastest.set_index(0) # will inner join on index
ibes_est3 = pd.merge(ibes_est2, lastest[['analys']], left_index=True, right_index=True)
# drop duplicate column
ibes_est3 = ibes_est3.drop(['analys_y'], axis=1).rename(columns={'analys_x': 'analys'})

# sanity check: only one forecast from each analyst for each firm-fpe
print("Sanity check: one forecast for each firm-fpe-analyst-> {}"
      .format(ibes_est3.groupby(['ticker','fpedats','estimator','analys'])['value'].count().unique()))


# query analysts' consensus data
ibes_con = conn.raw_sql(f"""
                        select ticker, fpedats, fpi, statpers,
                        medest as medcon, meanest as meancon, numest
                        from ibes.nstatsumu_epsus
                        where fpedats between '{begdate}' and '{enddate}'
                        and (fpi='6' or fpi='7')
                        and fiscalp='QTR'""", date_cols = ['fpedats','statpers'])
ibes_con = ibes_con.sort_values(by=['ticker','fpedats','fpi']).drop_duplicates()






#######################################
# Step 2. Link Estimates with Actuals #
#######################################
# Link Unadjusted estimates with Unadjusted actual earnings
# Keep the estimates issued within 90 days before repdats (the report date of actual earnings)
# Keep the latest consensus before repdats

# Getting actual piece of data
ibes_act = conn.raw_sql(f"""
                        select ticker, anndats as repdats, value as act,
                        pends as fpedats, pdicity, cname
                        from ibes.actu_epsus
                        where pends between '{begdate}' and '{enddate}'
                        and pdicity='QTR'
                        """, date_cols = ['repdats', 'fpedats'])

# Join actuals with the analysts' individual estimates
ibes = pd.merge(ibes_est3, ibes_act, how='left', on = ['ticker','fpedats'])
# Join actuals with the analysts' consensus
ibes_con1 = pd.merge(ibes_con, ibes_act, how='left', on = ['ticker','fpedats'])

# Gap between the day an estimate or concensus was issued and the actual EAD
ibes['dgap'] = ibes['repdats'] - ibes['anndats']
ibes_con1['dgap'] = ibes_con1['repdats'] - ibes_con1['statpers']

# Keep estimates issued within 90 days before the report date
ibes = ibes[(ibes.dgap>=dt.timedelta(days=0)) &
            (ibes.dgap<=dt.timedelta(days=90))].drop(['dgap', 'pdicity'], axis=1)


### NOTE ###
# Sanity check: only one forecast from each analyst for each firm-fpe
#ibes.groupby(['ticker','fpedats','estimator','analys'])['value'].count().unique()
# --> Not unique, however ibes_est3 passes the sanity check
# --> duplicates come from ibes_act, same day two actual EPS's
#a = ibes.groupby(['ticker','fpedats','estimator','analys'])['value'].count()==2
#a = a[a==True].reset_index()
#a = pd.merge(a, ibes1, on=['ticker','fpedats','estimator','analys'],how='left')
# or just check
#ibes_act.groupby(['ticker','fpedats','repdats'])['act'].count().unique()
# --> Conclusion: mistakes in database itself.
### END ###


# Keep the most recent consensus before EAD (98% fpi kept is '6')
ibes_con2 = ibes_con1[ibes_con1['dgap']>=dt.timedelta(days=0)]
ibes_con2 = ibes_con2.reindex(ibes_con2.groupby(by=['ticker','fpedats'])['dgap'].idxmin())
# Sanity check: only one consensus row for each firm-fpe
print("Sanity check: one consensus for each firm-fpe -> {}"
      .format(ibes_con2.groupby(['ticker','fpedats'])['statpers'].count().unique()))

# keep relevant columns
ibes_con2 = ibes_con2[['ticker', 'fpedats','statpers','medcon', 'meancon', 'numest']]

# merge analysts' estimates and consensus
ibes1 = pd.merge(ibes, ibes_con2, on=['ticker','fpedats'], how='left')





########################
# Step 3. CRSP BLOCK   #
########################
# Get cfacshr (for adjusting earnings),
# daily prc (for prcd), vol(for extracting EAD) from crspq.dsf
# Get monthly prc (for prcm) from crspq.msf
# NOTE: this next query may time out, in which case trying again my help.
# otherwise, it would be necessary to split into smaller periods and piece
# together later (see Piecing sue files section below)

# NOTE: this should be using crspq.dsf, but its having techinical difficiulties today

crspd = conn.raw_sql(f"""
                        select permno, date as trade_dats, cfacshr, prc as prcd, vol
                        from crsp.dsf
                        where date between '{crsp_begdate}' and '{crsp_enddate}'
                        """, date_cols = ['trade_dats'])
crspd['svol'] = crspd.groupby(['trade_dats'])['vol'].transform(lambda x: x/x.sum())

crspm = conn.raw_sql(f"""
                        select permno, date as trade_dats, prc as prcm
                        from crspq.msf
                        where date between '{crsp_begdate}' and '{crsp_enddate}'
                        """, date_cols = ['trade_dats'])

# Adjust all estimate and earnings announcement dates to the closest
# preceding trading date, to ensure that adjustment factors won't
# be missing after the merge
# trading dates from crspq.dsi
crsp_dt = conn.raw_sql("select date as trade_dats from crspq.dsi", date_cols=['trade_dats'])

# all relevant combinations of permnos and dates
ibes1_dt1 = ibes1[['permno', 'anndats']].drop_duplicates()
ibes1_dt2 = ibes1[['permno', 'repdats']].drop_duplicates().rename(columns={'repdats':'anndats'})
ibes1_dt3 = ibes1[['permno', 'statpers']].drop_duplicates().rename(columns={'statpers':'anndats'})
ibes_anndats = pd.concat([ibes1_dt1, ibes1_dt2, ibes1_dt3]).drop_duplicates()
uniq_dt = ibes_anndats[['anndats']].drop_duplicates()

# create dates up to 5 days before anndats
for i in range(0, 5):
    uniq_dt[i] = uniq_dt['anndats'] - dt.timedelta(days=i)

# reshape (transpose) the df (for later join with crsp trading dates)
expand_dt = (uniq_dt.set_index('anndats').stack().reset_index().
                  rename(columns={'level_1':'dgap', 0:'prior_date'}))

# merge with crsp trading dates
tradedates = pd.merge(expand_dt, crsp_dt, how='left',
                      left_on=['prior_date'], right_on=['trade_dats'])


### NOTE ###
# There are anndats having no trading days within 5 days prior to it
#tradedates.isna().sum()
### END ###

# choosing the row with the smallest dgap for a given anndats
td_closest = tradedates.reindex(tradedates.groupby('anndats')['dgap'].idxmin())
td_closest = td_closest[['anndats', 'trade_dats']]

# merge back to ibes_anndats: match anndats with the closets trading date
ibes_tdats = pd.merge(ibes_anndats, td_closest, how='left', on=['anndats'])

# merge with the CRSP adjustment factors 
ibes_cfa = pd.merge(ibes_tdats,crspd[['permno','trade_dats','cfacshr']],how='left',on=['permno','trade_dats'])



#########################################
# Step 4. Adjust Estimates with CFACSHR #
#########################################
# Adjust all earnings data with cfachr

# adjust analysts' estimates
ibes2 = pd.merge(ibes1, ibes_cfa, how='inner', on=['permno', 'anndats'])
ibes2 = ibes2.drop(['anndats','trade_dats'], axis=1).rename(columns={'cfacshr':'cfacshr_ann'})

# for ibes consensus
ibes3 = pd.merge(ibes2, ibes_cfa, how='inner',
                 left_on=['permno', 'statpers'], right_on=['permno','anndats'])
ibes3 = ibes3.drop(['statpers','anndats','trade_dats'], axis=1).rename(columns={'cfacshr':'cfacshr_con'})

# for ibes actual eps
ibes4 = pd.merge(ibes3, ibes_cfa, how='inner',
                 left_on=['permno', 'repdats'], right_on=['permno','anndats'])
ibes4 = ibes4.drop(['anndats','trade_dats'], axis=1).rename(columns={'cfacshr':'cfacshr_act'})

ibes4['new_value'] = (ibes4['cfacshr_act']/ibes4['cfacshr_ann'])*ibes4['value']
ibes4['meancon'] = (ibes4['cfacshr_act']/ibes4['cfacshr_con'])*ibes4['meancon']
ibes4['medcon'] = (ibes4['cfacshr_act']/ibes4['cfacshr_con'])*ibes4['medcon']

ibes4 = ibes4.sort_values(by=['ticker','fpedats',
                              'estimator','analys']).drop_duplicates()



# compute the median forecast based on estimates in the 90 days prior to the EAD
eps_exp = ibes4.groupby(['ticker','fpedats','act','meancon','medcon', 'numest',
        'repdats','permno','permco'])['new_value'].agg(['median','count']).reset_index()

# NOTE:
#  groupby keywords other than 'ticker' and 'fpedts' are added 
#  to keep the columns (to avoid another merge.)






############################
# Step 5. Compustat Block  #
############################
# - Extract EAD: 
#       Among the three-trading-day window, the day of the highest trading volume (scaled by market trading volume).
# - Three price denominators: prccq(quarter-end price), prcm(last-month-end price), and prcd(5-trading-day-before-EAD price)


comp = conn.raw_sql(f"""
                     select gvkey, conm, datadate, rdq,
                     cshoq, prccq from comp.fundq
                     where consol='C' and popsrc='D' and indfmt='INDL'
                     and datafmt='STD'
                     and datadate between '{crsp_begdate}' and '{crsp_enddate}'
                     """, date_cols = ['datadate', 'rdq'])


### EXTRACT EAD ###
# 1. get the closest trading days around announcements.
# 2. merge with the scaled trading volumes (svol).
# 3. keep the one with the highest svol.

# all earnings announcement dates
uniq_rdq = comp[['rdq']].drop_duplicates()
type(uniq_rdq) #need to be DataFrame

# create dates up to +/-5 days around rdq
for i in range(-5, 6):
    uniq_rdq[i] = uniq_rdq['rdq'] - dt.timedelta(days=i)

df_rdq = (uniq_rdq.set_index('rdq').stack().reset_index().
          rename(columns={'level_1':'daygap', 0:'date'}))

# merge with crsp trading dates
df_rdq = pd.merge(df_rdq, crsp_dt, how='left',
                      left_on=['date'], right_on=['trade_dats']).dropna()

# the last trading day before rdq, rdq(if it's on a trading day), one after rdq
day0 = df_rdq[df_rdq['daygap']==0]
day_m1 = df_rdq[df_rdq['daygap']<0]
day_m1 = day_m1.reindex(day_m1.groupby('rdq')['daygap'].idxmax())
day_p1 = df_rdq[df_rdq['daygap']>0]
day_p1 = day_p1.reindex(day_p1.groupby('rdq')['daygap'].idxmin())

rdq_dates = day0.append(day_m1).append(day_p1).sort_values(by=['rdq','daygap'])

# add trading dates back to comp
comp_td = pd.merge(comp, rdq_dates, on=['rdq'])

# add crsp trading volume

comp_td = pd.merge(comp_td, ccm, on=['gvkey'], how='left') # link comp and crsp
comp_td = comp_td[(comp_td['datadate']>=comp_td['linkdt'])&
                  (comp_td['datadate']<=comp_td['linkenddt'])]
# add scaled vol
ead = pd.merge(comp_td, crspd[['permno','svol','trade_dats']], on=['permno','trade_dats'])

# EAD determined as the trading day of the highest svol
ead = ead.reindex(ead.groupby(['gvkey','permno','rdq'])['svol'].idxmax())
ead = ead.rename(columns={'trade_dats':'ead'})
ead = ead.drop(columns=['linkdt','linkenddt','date','daygap','svol'])




### ADD CRSP PRICES ###

# to join on month-year
crspm['jmonth'] = crspm['trade_dats'].dt.month
crspm['jyear'] = crspm['trade_dats'].dt.year

from pandas.tseries.offsets import *
ead['premon'] = ead['ead']+MonthEnd(-1) #previous month of EAD
ead['jmonth'] = ead['premon'].dt.month
ead['jyear'] = ead['premon'].dt.year

# daily price 5 trading days before EAD
prcd = crspd[['permno','trade_dats','prcd']].copy()
prcd['jdats'] = prcd.groupby('permno')['trade_dats'].shift(-5)

# merge with ead

comp1 = pd.merge(ead, crspm, on=['permno','jmonth','jyear'], how='left')
comp1 = pd.merge(comp1, prcd, left_on=['permno','trade_dats'],
                 right_on=['permno','jdats'], how='left')

comp1 = comp1[['gvkey','conm','datadate','rdq','prccq','cshoq','ead',
               'permco','permno','prcm','prcd']]





########################
#  MERGE Comp and IBES #
########################

# effective range for a gvkey-ticker linkage
gvkey_dt = linkage.groupby(['gvkey', 'ticker']).agg({'linkdt':np.min,
                            'linkenddt':np.max}).reset_index().rename(
                    columns={'linkdt':'mindate','linkenddt':'maxdate'})


# match comp and ibes with effective dates
comp2 = pd.merge(comp1, gvkey_dt, how='left', on =['gvkey'])
comp2 = comp2[(comp2['ticker'].notna()) & (comp2['datadate']<=comp2['maxdate'])
             & (comp2['datadate']>=comp2['mindate'])]
sue = pd.merge(comp2, eps_exp, how = 'left',
                left_on=['ticker','datadate'], right_on=['ticker', 'fpedats'])

# Sort data and drop duplicates
sue = sue.sort_values(by=['gvkey','datadate']).drop_duplicates()

sue = sue.dropna(subset=['act'])

# sanity check, permno from comp and permno from eps_exp should be the same
#a = sue[sue.permno_x!=sue.permno_y]
#b = a[a.permco_x!=a.permco_y] #different permco's--> different companies
# indicating error in linkage database.
# -->eliminate rows with inconsistent permcos (only 38 rows are removed.)
sue = sue[sue['permno_x']==sue['permno_y']].drop(columns=['permco_y','permno_y','conm',
         'mindate','maxdate']).rename(columns={'permco_x':'permco','permno_x':'permno'})
conn.close()
with open(datadir + "sue2018_pre", 'wb') as f:
    pkl.dump(sue, f)




#%%##########################
#     Piecing sue files     #
#############################

# l = ["1980_1990","1990_2000","2000_2010","2010_2018","2018_pre"]
# l = ["2018_pre"]
# sue = pd.DataFrame()
# for t in l:
#     with open("data/sue"+t, "rb") as f:
#         df = pkl.load(f)
#     sue = sue.append(df)
sue = sue.drop_duplicates()
sue = sue.dropna(subset=['cshoq','prccq','prcd'])

# sanity check, unique obs for gvkey-datadate-permno pair
a = sue.groupby(by=['gvkey','datadate','permno'])['ead'].count()
print("number of obs for each gvkey-datadate-permno record: {}".format(a.unique()))

# not unique, some permno-ead have multiple obs
# create the column of number of obs of each gvkey-datadate-permno 
a = a.reset_index().rename(columns={'ead':'nobs'})
sue1 = pd.merge(sue, a, on=['gvkey','datadate','permno'], how='left')
sue1 = sue1.sort_values(by=['nobs','gvkey','permno','datadate'],ascending=[False,True,True,True])

# check the duplicity 
# --> multiple rdq from Compustat database, which is 
# probably due to error in database since the matching of rdq and gvkey is directly from Compustat.
# keep the rdq that's closer to EAD
df = sue1[sue1['nobs']==2]
df = df.reindex(df.groupby(['gvkey','permno','datadate'])['rdq'].idxmin())

sue = sue1[sue1['nobs']==1].append(df).drop(['nobs'],axis=1)

# sanity check, unique obs for gvkey-datadate-permno pair
a = sue.groupby(by=['gvkey','datadate','permno'])['ead'].count()
print("number of obs for each gvkey-datadate-permno record: {}".format(a.unique()))



#################################
# calculate sue's and filtering #
#################################
# sue1 = (act - medcon)/prcm, Engelberg et. al. (2018)
# sue2 = (act - medcon)/prcd, Dellavigna et al. (2009)
# sue3 = (act - median)/prccq, LM (2006) 

sue['sue1'] = (sue['act']-sue['medcon'])/sue['prcm']
sue['sue2'] = (sue['act']-sue['medcon'])/sue['prcd']
sue['sue3'] = (sue['act']-sue['median'])/sue['prccq']

sue = sue[['permno','ticker','ead','repdats','rdq','sue1','sue2','sue3']]
sue = sue.sort_values(by=['ead','permno'])

sue.to_csv(datadir + "earnings.csv", index=False)
###################
# End of Program  #
###################
