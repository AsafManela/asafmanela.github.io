using CategoricalArrays: isequal
import InfoVal
using InfoVal: tbldir, figdir, cachedir, settestmode,
        winsor, retain!, infoval, qport, eadeventtime!,
        dateconv, loadtaqms, loaddata, loadccm, loadearnings, T,
        up95, bt95, clean, agg, aggreg, aggregxsize, aggxsize,
        aggregxsxbm, aggxsxbm, summarystats, topobs, plotinfovalbypermno,
        drawinfoval, drawlninfoval, cachefile, cache, incache, loadclean, 
        settexresults, readtexresults, Params, regs, loadcpi, analyze
using Test, Dates, DataFrames, FixedEffectModels, VegaLite, CategoricalArrays, Random
using Dates: format
import Formatting

import Base.==
==(::Missing, ::Missing) = true

# set data and output paths to temp ones
settestmode(true)

@testset "InfoVal.jl" begin
    include("loaddata.jl")
    include("analysis.jl")
end
