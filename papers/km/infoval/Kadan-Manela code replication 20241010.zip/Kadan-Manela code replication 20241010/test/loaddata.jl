@testset "loaddata" begin
    # dateconv    
    @test dateconv(15958) == Date(2003,9,10)

    # retain
    rdf = DataFrame(date=[1,2,3,1,2,3], symbol=["a", "a", "a", "b", "b", "b"], v=[1,missing,missing,2,4,missing])
    retain!(rdf, [:symbol], [:date], [:v])

    @test rdf.date == [1,2,3,1,2,3]
    @test rdf.symbol == ["a", "a", "a", "b", "b", "b"]
    @test rdf.v == [1,1,1,2,4,4]

    rowlimit = 200000

    # eadeventtime!
    edf = DataFrame(date=[2,3,4,5,1,2,3,4], 
        symbol=["a", "a", "a", "a", "b", "b", "b", "b"], 
        permno=[1, 1, 1, 1, 2, 2, 2, 3], 
        ead=[true,false,false,false,false,true,false,false]
        )
    eadeventtime!(edf, 2)
    @test collect(skipmissing(edf.earntime)) == collect(skipmissing([0,1,2,missing,-1,0,1,missing]))
    @test ismissing(edf.earntime[4])
    @test_throws AssertionError eadeventtime!(sort(edf, :date))

    # infoval
    @test infoval(2, 1, 4) == 2/1*4
    @test infoval(2.0, 1.0, 4.0) == 2/1*4
    @test ismissing(infoval(missing, missing, 4))
    @test ismissing(infoval(2, missing, 4))
    @test ismissing(infoval(missing, 1, 4))
    @test ismissing(infoval(0, 0, 4))

    # winsor
    @test winsor([5,2,3,4,1], prop=0.2) == [4,2,3,4,2]

    # qport
    @test qport(0.0, [0.1, 0.5]) == 1
    @test qport(0.3, [0.1, 0.5]) == 2
    @test qport(1, [0.1, 0.5]) == 3

    params = Params(approach=:testlam, dir=:TEST, weighting="", test=true)

    cf = cachefile("infovaldf", params)
    @test cf == joinpath(cachedir(), "infovaldf$params.jld2")
    rm(cf, force=true)
    @test !incache(cf)
    cache(cf, edf)
    @test incache(cf)
    edf2 = cache(cf)
    @testset "edf[:$c]" for c in names(edf)
        @test edf[!, c] == edf2[!, c]
    end
    rm(cf, force=true)
    @test !incache(cf)

end

@testset "loaddata random data" begin

    # taqms
    taq = loadtaqms(; test=true)
    # @test size(taq,1) == rowlimit
    @test taq.date[1] == Date(2004,9,9)
    @test taq.yyyymm[1] == 200409
    @test issorted(taq, [:symbol, :date])
    @test ismissing(taq.lag1close[1])
    @test taq.lag1close[2] == taq.closeprice[1]
    ix = findfirst(isequal("[N"), taq.symbol)
    @test ismissing(taq.lag1close[ix])
    @test taq.lag1close[ix+1] == taq.closeprice[ix]
    @test sum(nonunique(taq, [:symbol, :date])) == 0

    # ccm
    ccm = loadccm(;test=true)
    @test typeof(ccm.szport) <: CategoricalArray
    @test typeof(ccm.bmport) <: CategoricalArray
    @test ccm.date[1] == Date(2001,8,9)
    @test "date" in names(ccm)
    @test issorted(ccm, [:symbol, :date])
    @test sum(nonunique(ccm, [:symbol, :date])) == 0

    # earnings
    ern = loadearnings(;test=true)
    @test eltype(ern.permno) <: Int
    @test eltype(ern.date) <: Date
    @test issorted(ern, [:permno, :date])
    @test sum(nonunique(ern, [:permno, :date])) == 0

    # cpi
    cpi = loadcpi(;test=true)
    @test eltype(cpi.yyyymm) <: Int
    @test eltype(cpi.cpifactor) <: Float64
    @test issorted(cpi, :yyyymm)
    @test sum(nonunique(cpi, :yyyymm)) == 0

    params = Params(test=true)

    # loaddata
    df = loaddata(params)
    @test issorted(df, [:permno, :date])
    @test sum(nonunique(df, [:symbol, :date])) == 0
    @test all(x->!ismissing(x), df.sue1[df.ead])
    @test all(x->ismissing(x), df.sue1[.! df.ead])

    # clean
    infovaldf = clean(df, params)
    @test infovaldf.σ[13] == sqrt(infovaldf.rv[13])
    @test infovaldf.V[13] ≈ infovaldf.rv[13] / infovaldf.λ[13] * infovaldf.lag1close[13] / 10^6
    @test infovaldf.λp[13] == infovaldf.λ[13] / infovaldf.lag1close[13] * 10^6
    uearntime = unique(infovaldf.earntime)
    @test ismissing(uearntime[1])

    #loadclean
    @test_logs (:info, "building clean infovaldf dataset") match_mode=:any infovaldf = loadclean(params)
    @test infovaldf.σ[13] == sqrt(infovaldf.rv[13])
    @test infovaldf.V[13] ≈ infovaldf.rv[13] / infovaldf.λ[13] * infovaldf.lag1close[13] / 10^6
    @test infovaldf.λp[13] == infovaldf.λ[13] / infovaldf.lag1close[13] * 10^6
    uearntime = unique(infovaldf.earntime)
    @test ismissing(uearntime[1])
    cf = cachefile("infovaldf", params)
    @test incache(cf)

    infovaldf2 = @test_logs (:info, "Loading clean infoval data for $params ...") (:info, "clean infovaldf loaded from $cf") loadclean(params)
    @testset "infovaldf[:$c]" for c in names(infovaldf)
        @test infovaldf[!, c] == infovaldf2[!, c]
    end
    rm(cf, force=true)
    @test !incache(cf)
end
