@testset "analysis" begin
    
    N = 100
    D = 20
    Random.seed!(13)

    startdate = Date(2020,4,25)
    enddate = Date(2020,4,25)+Day(D-1)
    startyyyymm = format(startdate, "yyyymm")
    endyyyymm = format(enddate, "yyyymm")

    tdf = DataFrame(
        date=rand(startdate:Day(1):enddate, N*D), 
        symbol=rand(["sym$i" for i=1:N], N*D), 
        permno=rand([i for i=1:N], N*D), 
        Vw=rand([10, 11, 9, 10, 4, 3, 5, 6.5, 7.5, 9.5, 10.5], N*D),
        Viw=rand([10, 11, 9, 10, 4, 3, 5, 6.5, 7.5, 9.5, 10.5], N*D),
        λp=rand([0.1, 0.11, 0.09, 0.1, 0.04, 0.03, 0.05, 0.03, 0.05, 0.03, 0.03], N*D),
        rvw=rand([1.0, 1.1, 0.9, 1.0, 0.4, 0.3, 0.5, 0.9, 1.1, 0.5, 0.7], N*D),
        σw=rand([1.0, 1.1, 0.9, 1.0, 0.4, 0.3, 0.5, 0.9, 1.1, 0.5, 0.7], N*D),
        σiw=rand([1.0, 1.1, 0.9, 1.0, 0.4, 0.3, 0.5, 0.9, 1.1, 0.5, 0.7], N*D),
        lag1close=rand([1.0, 1.1, 0.9, 1.0, 0.4, 0.3, 0.5, 0.9, 1.1, 0.5, 0.7], N*D),
        wt=rand([1.0, 1.1, 0.9, 1.0, 0.4, 0.3, 0.5, 0.9, 1.1, 0.5, 0.7], N*D),
        bemew=rand([1.0, 1.1, 0.9, 1.0, 0.4, 0.3, 0.5, 0.9, 1.1, 0.5, 0.7], N*D),
        momretw=rand([1.0, 1.1, 0.9, 1.0, 0.4, 0.3, 0.5, 0.9, 1.1, 0.5, 0.7], N*D),
        earntime=rand([-1,-0,1,missing,-1,0,1, -1, 0, 0, 1], N*D),
        ead=rand(Bool, N*D),
        szport=rand(["B","S"], N*D),
        bmport=rand(["H","M","L"], N*D),
        numest_excw=rand([10, 11, 9, 10, 4, 3, 5, 0], N*D),
        disp2w=rand([1.0, 1.1, 0.9, 1.0, 0.4, 0.3, 0.5, 0.9, 1.1, 0.5, 0.7], N*D),
    )

    tdf.yyyymm = [year(d)*100 + month(d) for d in tdf.date]
    tdf.wtw = winsor(tdf.wt)
    tdf.lnwtw = log.(tdf.wtw)
    tdf.λpw = winsor(tdf.λp)

    params = Params(approach=:testlam, dir=:TEST, weighting="", test=true)

    sdf = summarystats(tdf, params)
    @test size(sdf, 1) == 9

    topdf = topobs(tdf, params, n=10)
    @test size(topdf, 1) == 10*2 + 1

    topdf = topobs(tdf, params, n=5)
    @test size(topdf, 1) == 5*2 + 1

    drawname = "testtop10"
    p = plotinfovalbypermno(tdf, params; drawname=drawname)
    @test isfile(joinpath(figdir(), "Vw_bypermno$(params)_$drawname.pdf"))

    drawname = "testtop10"
    p = plotinfovalbypermno(tdf, params; drawname=drawname, yvar=:Vwhat)
    @test isfile(joinpath(figdir(), "Vwhat_bypermno$(params)_$drawname.pdf"))

    @testset "agg by $f" for f = [identity, lastdayofmonth, dayofweek]
        aggdf = aggreg(tdf, f, vcov=Vcov.simple())
        aggdf2 = agg(tdf, f)

        @test aggdf.date == aggdf2.date

        # agg uses meanratio while aggreg is the mean so will disagree
        # @test aggdf.Vw ≈ aggdf2.Vw
        
        @test aggdf.λpw ≈ aggdf2.λpw
        @test aggdf.rvw ≈ aggdf2.rvw

        if f ∈ [identity, lastdayofmonth]
            filepath = joinpath(figdir(), "infoval_monthterms$(params)_$(startyyyymm)_$endyyyymm.pdf")
            shades = true
        else
            filepath = joinpath(figdir(), "infoval_monthterms$(params)_1_7.pdf")
            shades = false
        end
        rm(filepath; force=true)

        @testset "$drawfn" for drawfn = [drawinfoval, drawlninfoval]
            (drawfn === drawlninfoval) && (filepath = replace(filepath, "infoval" => "lninfoval"))
            p = drawfn(aggdf, params, "month"; portfolios=false, shades=shades, terms=true, xtitle="Month")
            @test typeof(p) <: VegaLite.VLSpec
            @test isfile(filepath)
            rm(filepath; force=true)
        end
    end

    @testset "aggxsize by $f" for f = [lastdayofmonth]
        aggdf = aggregxsize(tdf, f, vcov=Vcov.simple())
        aggdf2 = aggxsize(tdf, f)

        # sort!(aggdf2, :)

        @test aggdf.date == aggdf2.date
        @test aggdf.Vw ≈ aggdf2.Vw

        if f ∈ [identity, lastdayofmonth]
            filepath = joinpath(figdir(), "infoval_month_size$(params)_$(startyyyymm)_$endyyyymm.pdf")
            shades = true
        else
            filepath = joinpath(figdir(), "infoval_month_size$(params)_2_7.pdf")
            shades = false
        end
        rm(filepath; force=true)

        @testset "$drawfn" for drawfn = [drawinfoval, drawlninfoval]
            (drawfn === drawlninfoval) && (filepath = replace(filepath, "infoval" => "lninfoval"))
            p = drawfn(aggdf, params, "month_size"; portfolios=true, shades=shades, terms=false, xtitle="Month")
            @test typeof(p) <: VegaLite.VLSpec
            @test isfile(filepath)
            rm(filepath; force=true)
        end
    end

    @testset "aggxsxbm by $f" for f = [lastdayofmonth]
        aggdf = aggregxsxbm(tdf, f, vcov=Vcov.simple())
        aggdf2 = aggxsxbm(tdf, f)

        @test aggdf.date == aggdf2.date
        @test aggdf.Vw ≈ aggdf2.Vw

        if f ∈ [identity, lastdayofmonth]
            filepath = joinpath(figdir(), "infoval_month_size$(params)_$(startyyyymm)_$endyyyymm.pdf")
            shades = true
        else
            filepath = joinpath(figdir(), "infoval_month_size$(params)_2_7.pdf")
            shades = false
        end
        rm(filepath; force=true)

        @testset "$drawfn" for drawfn = [drawinfoval, drawlninfoval]
            (drawfn === drawlninfoval) && (filepath = replace(filepath, "infoval" => "lninfoval"))
            p = drawfn(aggdf, params, "month_size"; portfolios=true, shades=shades, terms=false, xtitle="Month")
            @test typeof(p) <: VegaLite.VLSpec
            @test isfile(filepath)
            rm(filepath; force=true)
        end
    end

    @testset "agg byvar=earntime" begin
        aggdf = aggreg(tdf, identity; byvar=:earntime)
        aggdf2 = agg(tdf, identity; byvar=:earntime)

        @test aggdf.earntime == aggdf2.earntime
        
        # agg uses meanratio while aggreg is the mean so will disagree
        # @test aggdf.Vw ≈ aggdf2.Vw

        @test aggdf.λpw ≈ aggdf2.λpw
        @test aggdf.rvw ≈ aggdf2.rvw

        filepath = joinpath(figdir(), "infoval_earntimeterms$(params)_-1_1.pdf")
        rm(filepath; force=true)

        @testset "$drawfn" for drawfn = [drawinfoval, drawlninfoval]
            (drawfn === drawlninfoval) && (filepath = replace(filepath, "infoval" => "lninfoval"))
            p = drawfn(aggdf, params, "earntime"; byvar=:earntime, terms=true, dλ=(x=40,y=20),
                    xfield="earntime", xtype="ordinal", xtitle="Days relative to earnings announcement", dV=(x=-330,y=-150), drv=(x=40,y=-20))
            @test typeof(p) <: VegaLite.VLSpec
            @test isfile(filepath)
            rm(filepath; force=true)
        end
    end

    @testset "noteableresults" begin
        settexresults(params,
            "testkey1"=>"testres1", 
            "testkey2"=>4.5, 
            "testkey3"=>Formatting.format(19242.8242, commas=true, precision=0)
            )

        results = readtexresults(params)
        @test results["testkey1"] == "testres1"
        @test results["testkey2"] == "4.5"
        @test results["testkey3"] == "19,243"
    end

    @testset "regs" begin
        rs = regs(tdf, params, [:lnwtw])
    end

    @testset "analysis" begin
        analyze(tdf, params)
    end

end
