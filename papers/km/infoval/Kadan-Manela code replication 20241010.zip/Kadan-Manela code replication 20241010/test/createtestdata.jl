# create an anonymized test data set

using Test, Random
using Statistics: std, mean
import CSV
using InfoVal: load, loadccm, taqdir, wrdsdir, datadir, testdatadir, @take, DataFrame
using PooledArrays: PooledVector
using CategoricalArrays: isequal
import InfoVal
using InfoVal: tbldir, figdir, cachedir, settestmode,
        winsor, retain!, infoval, qport, eadeventtime!,
        dateconv, loadtaqms, loaddata, loadccm, loadearnings, T,
        up95, bt95, clean, agg, aggreg, aggregxsize, aggxsize,
        aggregxsxbm, aggxsxbm, summarystats, topobs, plotinfovalbypermno,
        drawinfoval, drawlninfoval, cachefile, cache, incache, loadclean, 
        settexresults, readtexresults, Params, regs, loadcpi, analyze
using Test, Dates, DataFrames, FixedEffectModels, VegaLite, CategoricalArrays, Random
using Dates: format
import Formatting
using CSV: String7

import Base.==
==(::Missing, ::Missing) = true

# set data and output paths to temp ones
settestmode(true)
# anonymize a vector of strings by reversing the order of the characters
# and then replacing each character with the next character in the ASCII table
function anonymize(v::Vector{T}, forcepos=false) where T <: Union{Missing, AbstractString}
    return [ismissing(s) ? missing : join(reverse([Char(Int(c) + 1) for c in s])) for s in v]
end

@test anonymize(["abc", "def", "XYZ"]) == ["dcb", "gfe", "[ZY"]
@test anonymize(["abc", "def", "XYZ", missing]) == ["dcb", "gfe", "[ZY", missing]
@test anonymize(convert.(String7,["abc", "def", "XYZ"])) == ["dcb", "gfe", "[ZY"]

# anonymize a vector of numbers by adding a random number to each with standard deviation equal to the sample standard deviation
function anonymize(v::Vector{T}, forcepos=false) where T <: Union{Missing, Real}
    N = length(v)

    if forcepos
        logv = broadcast(x->ismissing(x) || iszero(x) ? missing : log(x), v)
        σ = std(skipmissing(logv)) / 100
        ϵ = randn(N) * σ
        return exp.(log.(v) .+ ϵ)
    else
        σ = std(skipmissing(v)) / 100
        ϵ = randn(N) * σ
        return v .+ ϵ
    end    
end

v = 3 .+ [randn(10000); missing]
vanon = anonymize(v)
@test mean(skipmissing(v)) ≈ mean(skipmissing(vanon)) atol = 4
@test std(skipmissing(v)) ≈ std(skipmissing(vanon)) atol = 0.04

v = [exp.(log(3) .+ randn(10000)); [missing, 0.0]]
vanon = anonymize(v, true)
@test mean(skipmissing(v)) ≈ mean(skipmissing(vanon)) atol = 4
@test std(skipmissing(v)) ≈ std(skipmissing(vanon)) atol = 0.04

# anonymize a vector of integers (permno or yyyymm) by adding 2359 to each
function anonymize(v::Vector{T}, forcepos=false) where T <: Union{Missing, Integer}
    return [ismissing(i) ? missing : i + 2359 for i in v]
end

@test anonymize([1, 2, 3]) == [2360, 2361, 2362]

# anonymize a vector of dates by adding one year to each date
function anonymize(v::Vector{T}, forcepos=false) where T <: Union{Missing,Date}
    return [ismissing(d) ? missing : d + Year(1) for d in v]
end

@test anonymize([Date(2000, 3, 1), Date(2001, 3, 14)]) == [Date(2001, 3, 1), Date(2002, 3, 14)]
@test anonymize([Date(2000, 3, 1), Date(2001, 3, 14), missing]) == [Date(2001, 3, 1), Date(2002, 3, 14), missing]

# don't anonymize vectors of categorical data
anonymize(v::CategoricalVector{T}, forcepos=false) where T = v
anonymize(v::PooledVector{T}, forcepos=false) where T = v

@test anonymize(categorical(["a","b"])) == categorical(["a","b"])

# anonymize a dataframe by applying the anonymize function to each column
function anonymize(df::DataFrame; posreals::Vector{String} = [])
    DataFrame([anonymize(df[!, c], in(c, posreals)) for c in names(df)], names(df))
end

Random.seed!(123)

n = 100
rowlimit = 200000

##################################################
# taqms
##################################################
realdatafile = joinpath(taqdir(), "infoval.sas7bdat")
realtaq = load(realdatafile) |> @take(rowlimit) |> DataFrame

# pick n random symbols
keptsymbols = rand(unique(realtaq.SYM_ROOT), n)
ixsym = broadcast(in(keptsymbols), realtaq.SYM_ROOT)

# anonymize the data
anontaq = anonymize(realtaq[ixsym, :]; posreals=["irv60sec", "closeprice", "sumdollar", "sumsize"])

# compare the anonymized data to the original data
describe(realtaq[ixsym, :])
describe(anontaq)

# add one year to original dates and note that DATE is number of days since the epoch
anontaq.DATE = realtaq.DATE[ixsym] .+ 365
# taq date range
maxdate = maximum(anontaq.DATE)
# save the anonymized data to csv
CSV.write(joinpath(InfoVal.testdatadir(),"infoval.csv"), anontaq)

##################################################
# ccm
##################################################

realccm = CSV.read(joinpath(wrdsdir(), "ccm_daily.csv"), DataFrame)

# keep only symbols in the taqms data
ixsym = broadcast(x->(!ismissing(x) && in(x,keptsymbols)), realccm.tsymbol)
anonccm = anonymize(realccm[ixsym, :]; posreals=String["me","wt", "beme", "disp2", "numest_exc"])

# add 2359 to PERMNO
anonccm.permno = realccm.permno[ixsym] .+ 235

# covert tickers to String
anonccm.tsymbol = anonymize(String.(realccm.tsymbol[ixsym]))
anonccm.ticker = anonymize(String.(realccm.ticker[ixsym]))
anonccm.ibes_ticker = anonymize([ismissing(x) ? missing : String(x) for x in realccm.ibes_ticker[ixsym]])

# compare the anonymized data to the original data
describe(realccm[ixsym, :])
describe(anonccm)

# save the anonymized data to csv
CSV.write(joinpath(InfoVal.testdatadir(),"ccm.csv"), anonccm)

# store permnos for later matching
keptpermnos = unique(realccm[ixsym, :permno])

##################################################
# earnings
##################################################

realearn = CSV.read(joinpath(datadir(), "earnings", "earnings.csv"), DataFrame)

# keep only kept permnos in the ccm data
ixpermno = broadcast(x->(!ismissing(x) && in(x,keptpermnos)), realearn.permno)

# anonymize the data
anonearn = anonymize(realearn[ixpermno, :]; posreals=String[])

# covert tickers to String
anonearn.ticker = anonymize(String.(realearn.ticker[ixpermno]))

# add 2359 to PERMNO
anonearn.permno = Int.(realearn.permno[ixpermno] .+ 235)

# compare the anonymized data to the original data
describe(realearn[ixpermno, :])
describe(anonearn)

# save the anonymized data to csv
CSV.write(joinpath(InfoVal.testdatadir(),"earnings.csv"), anonearn)

##################################################
# test
##################################################

# load the anonymized data
using InfoVal: Params, loaddata
df = loaddata(Params(test=true))