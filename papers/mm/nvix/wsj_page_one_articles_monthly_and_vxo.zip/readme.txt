Data and code may be used for non-commercial purposes free of charge. It is provided as is, without any guarantees of correctness. If you find any issues with these please email me at amanela@wustl.edu

This zip file contains monthly phrase counts of Wall Street Journal frontpage titles and abstracts, normalized by total phrase count each month.

Please reference the following paper for construction details:
Manela, Asaf and Alan Moreira, News Implied Volatility and Disaster Concerns, Journal of Financial Economics, forthcoming

The file nvix is an example bash script file that can be used to replicate our nvix series. It does not generate all the results in the paper, but is instead meant to help researchers that are new to machine learning get started with using support vector regression with text.

The data is formatted in svmlight format. For details of this format and for installation instructions of svmlight see: http://svmlight.joachims.org/

The files TF_train.txt, TF_test.txt, and TF_predict.txt are our train, test, and predict subsamples, and follow the following format:

Each line is a monthly observation.
The first number on each row is our target variable, end-of-month VXO, when available.
Next is a sparse representation of <feature number>:<normalized ngram count>
The end of each line, has an svmlight comment (after the #), where we indicate the data of the observation.

The file superDictionary.txt maps feature numbers to ngrams (we use unigrams and bigrams). It also lists their frequency in each of the subsamples.


